﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisLey_ProyectoNo._1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            
            this.Hide();
        }
        Form2 frm2 = new Form2();

        private void btnModificarU_Click(object sender, EventArgs e)
        {
           // frm2.Show();
            if (frm2.ShowDialog() == DialogResult.OK)
            {
                Usuario_Modificado();
            }
            Usuario_Modificado();
            MessageBox.Show("FUE NECESARIO CERRAR SESIÓN ");
            
        }
        Usuarios temp;
        public Usuarios Usuario_Modificado()
        {
            temp = frm2.RetornoDatoUs();
            frm2.Close();
            return temp;
        }

    }
}
