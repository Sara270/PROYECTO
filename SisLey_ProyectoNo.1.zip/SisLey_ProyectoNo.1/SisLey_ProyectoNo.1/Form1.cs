﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisLey_ProyectoNo._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listaUsuarios = new ListaUser();

        }
        public ListaUser listaUsuarios;
        Usuarios us;
        private void btnLogIn_Click(object sender, EventArgs e)
        {
            for (int i = 0;  i < listaUsuarios.cima; i++){

                if (this.txtNombre.Text == listaUsuarios.Usuarios[i].nombre){
                    
                if (this.txtContra.Text == listaUsuarios.Usuarios[i].contraseña) {
                    Form3 frm3 = new Form3();
                    MessageBox.Show("BIENVENIDO " + listaUsuarios.Usuarios[i].nombre);
                    frm3.Show();

                    break;
                } else {
                    MessageBox.Show("Contraseña Incorrecta");
                }
             }
                if (i == listaUsuarios.limite - 1)
                {
                    MessageBox.Show("No Existe");
                }
                    
          }
            MessageBox.Show("No Existe");
        }
        Form2 frm = new Form2();
        Form3 frm3 = new Form3();
        private void btnCreate_Click(object sender, EventArgs e)
        {
           
            this.Hide();
            frm.ShowDialog();
            this.Show();
            Recibe();
            
            frm3.ShowDialog();
            
        }
        public void Recibe(){
           Usuarios us = frm.RetornoDatoUs();
           listaUsuarios.Add_Usuarios(us);
        }
        public void Restablecer_Usuario()
        {
            Usuarios temp1 = frm3.Usuario_Modificado();
            for (int i = 0; i < listaUsuarios.limite; i++)
            {
                if (this.txtNombre.Text == listaUsuarios.Usuarios[i].nombre)
                {
                    listaUsuarios.Usuarios[i] = temp1;
                    txtNombre.Text = null;
                    txtContra.Text = null; 
                }
            }
        }

    }
}
