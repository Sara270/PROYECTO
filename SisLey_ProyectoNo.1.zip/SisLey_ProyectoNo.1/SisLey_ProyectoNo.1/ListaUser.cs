﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SisLey_ProyectoNo._1
{
    class ListaUser
    {
        private Usuarios[] Usuarios;
        private int cima=-1;
        private int limite;
        private bool vacio;
        private bool lleno;
        /////////////////////////////////
        private Usuarios valor;

       
        private bool Valida_vacia_Usuarios()
        {
            if (Usuarios[0] == default(Usuarios))
            {
                vacio = true;
            }
            else
            {
                vacio = false;
            }
            return vacio;
        }


        private bool Valida_lleno_Usuarios()
        {
            if (Usuarios[0] != default(Usuarios))
            {
                lleno = true;
            }
            else
            {
                lleno = false;
            }
            return lleno;
        }

        public void Add_Usuarios(Usuarios d)
        {
            if (Valida_vacia_Usuarios() && cima < 0)
            {
                Usuarios[0] = d;
                cima++;
            }
            else
            {
                if (cima < limite)
                {
                    cima++;
                    Usuarios[cima] = d;
                }
            } 
        }

        // Revisar 

        public Usuarios Remove(int puntero)
        {
            if (Valida_lleno_Usuarios() && puntero <= cima)
            {
                if (puntero == cima)
                {
                    valor = Usuarios[puntero];
                    Usuarios[cima] = default(Usuarios);
                    cima--;
                }
                else
                {
                    valor = Usuarios[puntero];
                    for (int i = puntero; i < cima; i++)
                    {
                        Usuarios[i] = Usuarios[i + 1];
                    }
                    Usuarios[cima] = default(Usuarios);
                    cima--;
                }
            }
            else
            {
                Console.WriteLine("La lista no posee valor en la posicion especificada");
            }
            return valor; 
        }

    }
}
