﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SisLey_ProyectoNo._1
{
    public class ListaUser
    {
        public Usuarios[] Usuarios;
        public int cima=0;
        public int limite;
        private bool vacio;
        private bool lleno;
        /////////////////////////////////
        private Usuarios valor;

        public ListaUser()
        {
            Usuarios = new Usuarios [9];
            limite = 9;
        }
        private bool Valida_vacia_Usuarios()
        {
            if (Usuarios[0] == default(Usuarios))
            {
                vacio = true;
            }
            else
            {
                vacio = false;
            }
            return vacio;
        }


        private bool Valida_lleno_Usuarios()
        {
            if (Usuarios[0] != default(Usuarios))
            {
                lleno = true;
            }
            else
            {
                lleno = false;
            }
            return lleno;
        }

        public void Add_Usuarios(Usuarios d)
        {
           
                if (cima < limite)
                {
                    Usuarios[cima] = d;
                    cima++;
                }
            
        }

        
        public Usuarios Remove(int puntero)
        {
            if (Valida_lleno_Usuarios() && puntero <= cima)
            {
                if (puntero == cima)
                {
                    valor = Usuarios[puntero];
                    Usuarios[cima] = default(Usuarios);
                    cima--;
                }
                else
                {
                    valor = Usuarios[puntero];
                    for (int i = puntero; i < cima; i++)
                    {
                        Usuarios[i] = Usuarios[i + 1];
                    }
                    Usuarios[cima] = default(Usuarios);
                    cima--;
                }
            }
            else
            {
                Console.WriteLine("La lista no posee valor en la posicion especificada");
            }
            return valor; 
        }


    }
}
