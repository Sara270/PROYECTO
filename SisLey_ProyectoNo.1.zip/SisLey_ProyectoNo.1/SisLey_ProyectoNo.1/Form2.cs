﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisLey_ProyectoNo._1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private Lista listaAsesor;
        
        private void txtNombreDip_TextChanged(object sender, EventArgs e)
        {
             
        }
        private void btnNombreDi_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            txtNombreDip.Visible = false;
            btnNom.Visible = false;
        }
        private void btnCreado_Click(object sender, EventArgs e)
        {
            string nom;
            string nomAsesor;
            int numase;
            nom = txtNombreDip.Text;

            nomAsesor = txtNomAsesor.Text;
            numase = int.Parse(mTxtCasesores.Text);
           
            Usuarios us = new Usuarios(nom, numase, nomAsesor);
          
            Form3 frm = new Form3();

            this.Hide();
            frm.ShowDialog();
            this.Show();
        }

        private void mTxtCasesores_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            
        }

        private void b(object sender, EventArgs e)
        {

        }

        private void GuardarCantAsesor_Click(object sender, EventArgs e)
        {
            int c;
            c = int.Parse(mTxtCasesores.Text);
            label2.Visible = false;
            mTxtCasesores.Visible = false;
            GuardarCantAsesor.Visible = false;
        }
        int boton = 0;
        private void btnGuardarAse_Click(object sender, EventArgs e)
        {
            
            int c;
            c = int.Parse(mTxtCasesores.Text);
            string nomAsesor;
            boton ++;
            nomAsesor = txtNomAsesor.Text;
           // listaAsesor.Add_Asesor(nomAsesor);
            if (c == boton)
            {
                label3.Visible = false;
                btnGuardarAse.Visible = false;
                txtNomAsesor.Visible = false;
            }
            txtNomAsesor.Clear();
        }
    }
}
