﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_1
{
    public class Ley
    {
        public Lista listaReglamentos;
        public string nomLey;
        private int cantReglamentos;
        public PilaCopias pilaCopies = new PilaCopias(5);
        public PilaCopias pilaReglamentos = new PilaCopias(5); 


        public Ley(string nL, int cRegla, Lista nomRegla)
        {
            this.nomLey = nL;
            this.listaReglamentos = nomRegla;
            this.cantReglamentos = cRegla;
            pilaCopies.Push(nL);
            pilaCopies.Push(nL);
            pilaCopies.Push(nL);
            pilaCopies.Push(nL);
        }

    }
}
