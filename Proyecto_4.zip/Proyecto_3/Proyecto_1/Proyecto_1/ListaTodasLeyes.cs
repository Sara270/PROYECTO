﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_1
{
    public class ListaTodasLeyes
    {
       
        public Ley[] Leyes;
        public int cima2 = 0;
        public int limite2;
        private bool vacio2;
        private bool lleno2;
        /////////////////////////////////
        private Ley valor3;

      
         public ListaTodasLeyes()
        {
            Leyes= new Ley[200];
            limite2 = 200;
        }
        private bool Valida_vacia_Leyes()
        {
            if (Leyes[0] == default(Ley))
            {
                vacio2 = true;
            }
            else
            {
                vacio2 = false;
            }
            return vacio2;
        }


        private bool Valida_lleno_Leyes()
        {
            if (Leyes[0] != default(Ley))
            {
                lleno2 = true;
            }
            else
            {
                lleno2 = false;
            }
            return lleno2;
        }

        public void Add_Leyes(Ley d)
        {

            if (cima2 < limite2)
            {
                Leyes[cima2] = d;
                cima2++;
               
            }

        }
    


        public Ley Remove(int puntero)
        {
            if (Valida_lleno_Leyes() && puntero <= cima2)
            {
                if (puntero == cima2)
                {
                    valor3 = Leyes[puntero];
                    Leyes[cima2] = default(Ley);
                    cima2--;
                }
                else
                {
                    valor3 = Leyes[puntero];
                    for (int i = puntero; i < cima2; i++)
                    {
                         Leyes[i] = Leyes[i + 1];
                    }
                    Leyes[cima2] = default(Ley);
                    cima2--;
                }
            }
            else
            {
                Console.WriteLine("La lista no posee valor en la posicion especificada");
            }
            return valor3;
        }
        public int MayorRegla2()
        {
            int mayor = 0;
            mayor = int.MinValue;

            for (int i = 0; i < Leyes.Length; i++)
            {
                if (Leyes[i] == null)
                {
                    break;
                }
                if (Leyes[i].listaReglamentos.listaReglamentos.Length > mayor)
                {
                    mayor = Leyes[i].listaReglamentos.listaReglamentos.Length;
                }
            }
            return mayor;
        }

    }
}
