﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_1
{
   public class PilaCopias
    {
         private int cima;
        private int limite;
        private string valor;
        private string[] arreglo;
        private bool vacio;
        private bool lleno;

        /// <summary>
        /// Constructor de la clase Cola
        /// </summary>
        /// <param name="Ilimite">El limite de la cola</param>
        public PilaCopias(int Ilimite)
        {
            cima = -1;
            limite = Ilimite;
            valor = "";
            arreglo = new string[limite];
            vacio = false;
            lleno = false;
        }


        /// <summary>
        /// Valida si la pila esta vacia
        /// </summary>
        /// <returns>Retorna un valor verdadero si esta vacio y falso si esta lleno</returns>
        private bool Valida_vacia()
        {
            if (arreglo[0] == default(string))
            {
                vacio = true;
            }
            else
            {
                vacio = false;
            }
            return vacio;
        }

        /// <summary>
        /// Valida si la pila esta lleno
        /// </summary>
        /// <returns>Retorna un valor verdadero si esta llena y falso si esta vacia</returns>
        private bool Valida_lleno()
        {
            if (arreglo[0] != default(string))
            {
                lleno = true;
            }
            else
            {
                lleno = false;
            }
            return lleno;
        }

        /// <summary>
        /// Se agrega el valor recibido a la pila en la posicion vacia
        /// </summary>
        /// <param name="valor_ingresado">Dato a ingresar en la pila</param>
        public void Push(string valor_ingresado)
        {
            if (Valida_vacia() && cima < 0)
            {
                arreglo[0] = valor_ingresado;
                cima++;
            }
            else
            {
                if (cima < limite)
                {
                    cima++;
                    arreglo[cima] = valor_ingresado;
                }
            }
        }

        /// <summary>
        /// La funcion devuelve el primer dato que ingreso
        /// </summary>
        /// <returns>El primer dato que entro es el primero que sale</returns>
        public string Pop()
        {
            if (Valida_lleno())
            {
                valor = arreglo[cima];
                arreglo[cima] = default(string);
                cima--;
            }
            else
            {
                valor = "Entro a la Lista de Espera";
            }
            return valor;
        }

        /// <summary>
        /// Verifica el numero de elementos que hay en la pila
        /// </summary>
        /// <returns>Retorna el numero de elementos de la pila</returns>
        public int Count1()
        {
            return cima+1;
        }
    }
}
