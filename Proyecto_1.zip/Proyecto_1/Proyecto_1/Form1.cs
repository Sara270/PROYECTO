﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listaUsuarios = new ListaUser();
            listaDeLeyes = new ListaLeyes();
            pilaCopies = new PilaCopias();
            listaDeLeyesCompleta = new ListaTodasLeyes();
        }
        public ListaUser listaUsuarios;
        public ListaLeyes listaDeLeyes;
        public Lista listaAsesor;
        public Lista listaReglamentos;
        public PilaCopias pilaCopies;
        public ListaTodasLeyes listaDeLeyesCompleta;
        Usuarios us;
        Ley l;
        PilaCopias pc;
        ListaTodasLeyes lc;
        Asesores ase;
        int botonCantRe = 0;
        int variableSesion=-1;

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            
            for (int j = 0; j < listaUsuarios.cima; j++)
            {
                if (this.txtNombre.Text == listaUsuarios.Usuarios[j].nombre)
                {
                   
                    if (this.txtContra.Text == listaUsuarios.Usuarios[j].contraseña)
                    {
                        MessageBox.Show("Bienvenido: " + listaUsuarios.Usuarios[j].nombre);
                        pnUsuario.Visible = true;
                        pnInicio.Visible = false;
                        botonCantRe = 0;
                        variableSesion = j;
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Contraseña Incorrecta");
                    }
                }
                if (j == listaUsuarios.limite - 1)
                {
                    MessageBox.Show("No Existe");
                }
                if (j<listaUsuarios.Usuarios[j].listaAsesor.cima && this.txtNombre.Text == listaUsuarios.Usuarios[j].listaAsesor.listaAsesor[j].nombre)
                {
                    MessageBox.Show("Bienvenido: " + listaUsuarios.Usuarios[j].listaAsesor.listaAsesor[j].nombre);
                    pnUsuario.Visible = true;
                    pnInicio.Visible = false;
                    botonCantRe = 0;
                    break;
                }
             
            }
            MessageBox.Show("No Existe :)");
            
        }
        int boton2=0;
        private void btnCreate_Click(object sender, EventArgs e)
        {
            listaDeLeyes = new ListaLeyes();
            pnInicio.Hide();
            if (boton2 < 9)
            {
                lblDip.Visible = true;
                txtNombreDip.Clear();
                txtNombreDip.Visible = true;
                btnNom.Visible = true;

                boton = 0;
                botonCantRe = 0;
                lblCantA.Visible = true;
                mTxtCasesores.Clear();
                mTxtCasesores.Visible = true;
                GuardarCantAsesor.Visible = true;

                btnContra.Visible=true;
                lblContra.Visible = true;
                txtContraseña.Clear();
                txtContraseña.Visible=true;

                lblNomA.Visible = true;
                btnGuardarAse.Visible = true;
                txtNomAsesor.Clear();
                txtNomAsesor.Visible = true;



                pnCreate.Visible = true;
                boton2++;
            }
            else
            {
                MessageBox.Show("No caben más Usuarios");
            }
            variableSesion = -1;
            
            
        }
       
        private void btnNom_Click(object sender, EventArgs e)
        {
            lblDip.Visible = false;
            txtNombreDip.Visible = false;
            btnNom.Visible = false;

        }

        private void GuardarCantAsesor_Click(object sender, EventArgs e)
        {
            int c;
            c = int.Parse(mTxtCasesores.Text);
            if (c > 8)
            {
                MessageBox.Show("Máximo de asesores 8");
            }
            else
            {
                lblCantA.Visible = false;
                mTxtCasesores.Visible = false;
                GuardarCantAsesor.Visible = false;
                listaAsesor = new Lista(true, int.Parse(mTxtCasesores.Text), 0);
            }
           

        }
        int boton = 0;

        private void btnGuardarAse_Click(object sender, EventArgs e)
        {
            
            int c;
            c = int.Parse(mTxtCasesores.Text);
            string nomAsesor;
            boton++;
            nomAsesor = txtNomAsesor.Text;
            ase = new Asesores(nomAsesor, listaDeLeyes);
            listaAsesor.Add_Asesor(ase);

            if (c == boton)
            {
                lblNomA.Visible = false;
                btnGuardarAse.Visible = false;
                txtNomAsesor.Visible = false;
                btnSiguiente.Visible = true;
            }
            txtNomAsesor.Clear();
        }

        private void btnContra_Click(object sender, EventArgs e)
        {
            btnContra.Hide();
            lblContra.Hide();
            txtContraseña.Hide();
        }

        private void btnCreado_Click(object sender, EventArgs e)
        {
            
                string nom;
                int numAse;
                nom = txtNombreDip.Text;
                string contraseña;
                contraseña = txtContraseña.Text;
                numAse = int.Parse(mTxtCasesores.Text);
                us = new Usuarios(nom, numAse, listaAsesor, contraseña, listaDeLeyes);
                Recibe();
                variableSesion = listaUsuarios.cima-1;
                listaUsuarios.Usuarios[variableSesion].AgregaLeyes(l);
                pnUsuario.Visible = true;
                pnLeyes.Visible = false;
          
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            pnUsuario.Visible = false;
            pnInicio.Visible = true;
            /////////////////////// AL INGRESAR OTRA VEZ CON EL MISMO USUARIO SE CREA UN NUEVO USUARIO TRAS PRESIONAR CREAR/////////////////
            variableSesion= - 1;
       }

        public Usuarios RetornoDatosUs()
        {
          //  us.listaAsesor = this.listaAsesor;
            return us;
        }
        public void Recibe()
        {
            Usuarios nuevo;
            nuevo = RetornoDatosUs();
            listaUsuarios.Add_Usuarios(nuevo);
        }

        private void btnEliminarU_Click(object sender, EventArgs e)
        {

            pnInicio.Visible = false;
            pnUsuario.Visible = false;
            pnCreate.Visible = false;
            pnElimina.Visible = true;
        }

        private void btnEliminado_Click(object sender, EventArgs e)
        {
            string UserR;
            UserR=txtNomEliminar.Text;
             for (int k = 0; k < listaUsuarios.cima; k++)
            {
                if (UserR == listaUsuarios.Usuarios[k].nombre)
                {
                   listaUsuarios.Remove(k);
                   MessageBox.Show("Eliminado");
                   pnElimina.Visible = false;
                   pnInicio.Visible = true;
                }
                if (k == listaUsuarios.limite - 1)
                {
                    MessageBox.Show("No Existe");
                }
            }
            MessageBox.Show("No Existe :)");
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnModificarU_Click(object sender, EventArgs e)
        {
            pnUsuario.Visible = false;
            pnModificar.Visible = true;
        }

        private void btnModificado_Click(object sender, EventArgs e)
        {
             string nomModificar;
            nomModificar = txtUsuarioModificar.Text;
           
            for (int k = 0; k < listaUsuarios.cima; k++)
            {
                if (nomModificar == listaUsuarios.Usuarios[k].nombre)
                {
                    

                    lblDip.Visible = true;
                    txtNombreDip.Clear();
                    txtNombreDip.Visible = true;
                    btnNom.Visible = true;

                    boton = 0;
                    lblCantA.Visible = true;
                    mTxtCasesores.Clear();
                    mTxtCasesores.Visible = true;
                    GuardarCantAsesor.Visible = true;

                    btnContra.Visible = true;
                    lblContra.Visible = true;
                    txtContraseña.Clear();
                    txtContraseña.Visible = true;

                    lblNomA.Visible = true;
                    btnGuardarAse.Visible = true;
                    txtNomAsesor.Clear();
                    txtNomAsesor.Visible = true;

                    
                    pnCreate.Visible = true;

                    //listaUsuarios.Remove(k);


                    //string nomModificado=txtNombreDip.Text;
                    //int numAseMod=int.Parse(mTxtCasesores.Text);
                    //string contraseñaMod = txtNomAsesor.Text;

                    //us = new Usuarios(nomModificado, numAseMod, listaAsesor, contraseñaMod);
                    //Recibe();

                }
                if (k == listaUsuarios.limite - 1)
                {
                    MessageBox.Show("No Existe");
                }
            }
            MessageBox.Show("No Existe :)");

            }
        Usuarios mod;
        public Usuarios Usuario_Modificado()
        {
            mod = RetornoDatosUs();
            return mod;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            btnCreado.Visible = false;
            pnUsuario.Visible = false;
            pnLeyes.Visible = true;
            
            lblCantidadReglamentos.Visible = true;
            mTxtCantRegla.Clear();
            mTxtCantRegla.Visible = true;
            btnGuardarCantRegla.Visible = true;
            lblReglamento.Visible = true;
            txtReglamento.Visible = true;
            btnGuardarRegla.Visible = true;
            btnLeyCreada.Visible = true;
            rbtnLeyNueva.Visible = true;
            rbtnLeyNueva.Checked = false;
            txtLeyNueva.Visible = true;
            txtLeyNueva.Clear();
            txtLeyExistente.Visible = true;
            rLblLeyExistente.Visible = true;
            rLblLeyExistente.Checked = false;
            btnAgregarLeyExistente.Visible = true;
            btnModLey.Visible = true;
            btnEliminarLey.Visible = true;
            btnGuardarLey.Visible = true;

        }

        private void btnLeyCreada_Click(object sender, EventArgs e)
        {
            if (variableSesion != -1)
            {
                btnCreado.Visible = false;
                pnUsuario.Visible = true;
                pnLeyes.Visible = false;
                btnCreado.Visible = false;
            }
            else
            {
                btnCreado.Visible = true;
                lblCantidadReglamentos.Visible = false;
                mTxtCantRegla.Visible = false;
                btnGuardarCantRegla.Visible = false;
                lblReglamento.Visible = false;
                txtReglamento.Visible = false;
                btnGuardarRegla.Visible = false;
                btnLeyCreada.Visible = false;
            }

            //if (!listaUsuarios.Valida_Existe_Usuario(listaUsuarios.Usuarios[variableSesion])) /// niega el if
            //{

            //    lblCantidadReglamentos.Visible = false;
            //    mTxtCantRegla.Visible = false;
            //    btnGuardarCantRegla.Visible = false;
            //    lblReglamento.Visible = false;
            //    txtReglamento.Visible = false;
            //    btnGuardarRegla.Visible = false;
            //    btnLeyCreada.Visible = false;

            //}
            //else
            //{

            //pnUsuario.Visible = true;
            //pnLeyes.Visible = false;
            //btnCreado.Visible = false;
            //}   
            botonCantRe = 0;
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            pnCreate.Visible = false;
            pnLeyes.Visible = true;
            botonCantRe = 0;
            lblCantidadReglamentos.Visible = true;
            mTxtCantRegla.Clear();
            mTxtCantRegla.Visible = true;
            btnGuardarCantRegla.Visible = true;
            lblReglamento.Visible = true;
            txtReglamento.Visible = true;
            btnGuardarRegla.Visible = true;
            btnLeyCreada.Visible = true;
            rbtnLeyNueva.Visible = true;
            rbtnLeyNueva.Checked = false;
            txtLeyNueva.Visible = true;
            txtLeyNueva.Clear();
            txtLeyExistente.Visible = true;
            txtLeyExistente.Clear();
            rLblLeyExistente.Visible = true;
            rLblLeyExistente.Checked = false;
            btnAgregarLeyExistente.Visible = true;
            btnModLey.Visible = true;
            btnEliminarLey.Visible = true;
            btnGuardarLey.Visible = true;

        }

        private void btnGuardarCantRegla_Click(object sender, EventArgs e)
        {
            int d;
            d = int.Parse(mTxtCantRegla.Text);
            lblCantidadReglamentos.Visible = false;
            mTxtCantRegla.Visible = false;
            btnGuardarCantRegla.Visible = false;
            listaReglamentos = new Lista(false, int.Parse(mTxtCasesores.Text), int.Parse(mTxtCantRegla.Text));   
        }
        
        private void btnGuardarRegla_Click(object sender, EventArgs e)
        {
            int d;
            d = int.Parse(mTxtCantRegla.Text);
            string nomRegla;
            string nomLey;
            nomLey = txtLeyNueva.Text;
            botonCantRe++;
            nomRegla = txtReglamento.Text;
            listaReglamentos.Add_Reglamentos(nomRegla);
            if (d == botonCantRe)
            {
                lblReglamento.Visible = false;
                btnGuardarRegla.Visible = false;
                txtReglamento.Visible = false;
            }
            txtReglamento.Clear();
            
            l = new Ley(nomLey, d, listaReglamentos);
           // listaDeLeyes = new ListaLeyes();
            if (variableSesion != -1)
            {
                listaUsuarios.Usuarios[variableSesion].AgregaLeyes(l);
            }
            
            

            // Agrega la ley a una Lista de Leyes Completas //
            Recibe2();
            
          }

        public void Recibe2()
        {
            Ley nuevaLey;
            nuevaLey = RetornoDatosUs2();
            listaDeLeyesCompleta.Add_Leyes(nuevaLey);
        }
        public Ley RetornoDatosUs2()
        {
            return l;
        }
        /// <summary>
        /// //////////////////////
        /// </summary>
        public void Recibe3()
        {
            PilaCopias CopiasAgregadas;
            CopiasAgregadas = RetornoDatosUs3();
            pilaCopies.Push(CopiasAgregadas);
            
        }

        public PilaCopias RetornoDatosUs3()
        {
            return pc;
        }

        /// <summary>
        /// //////////////////////
        /// </summary>

        private void btnGuardarLey_Click(object sender, EventArgs e)
        {
            txtLeyNueva.Visible = false;
            rbtnLeyNueva.Visible = false;
            btnGuardarLey.Visible = false;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            txtLeyNueva.Visible = false;
            rbtnLeyNueva.Visible = false;
            btnGuardarLey.Visible = false;
            lblCantidadReglamentos.Visible = false;
            mTxtCantRegla.Visible = false;
            btnGuardarCantRegla.Visible = false;
            btnLeyCreada.Visible = false;
            lblReglamento.Visible = false;
            txtReglamento.Visible = false;
            btnGuardarRegla.Visible = false;
        }

        private void rbtnLeyNueva_CheckedChanged(object sender, EventArgs e)
        {
            rLblLeyExistente.Visible = false;
            btnAgregarLeyExistente.Visible = false;
            btnModLey.Visible = false;
            btnEliminarLey.Visible = false;
            txtLeyExistente.Visible = false;
        }
        
        ////////////////////////////////////////////////////////

        private void txtLeyExistente_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAgregarLeyExistente_Click(object sender, EventArgs e)
        {
            string LeyAgregadaExistente;
            LeyAgregadaExistente = txtLeyExistente.Text;
            
            for (int k = 0; k < listaDeLeyes.cima2; k++)
            {
                if (LeyAgregadaExistente == listaDeLeyesCompleta.Leyes[k].nomLey)
                {
                    
                    MessageBox.Show("Ley Agregada");
                    
                    break;
                }
                if (k == listaUsuarios.limite - 1)
                {
                    MessageBox.Show("No Existe");
                }
            }
            MessageBox.Show("No Existe :)");
            pnLeyes.Visible = false;
            pnUsuario.Visible = true;

        }

        private void btnEliminarLey_Click(object sender, EventArgs e)
        {
            string LeyEliminada;
            LeyEliminada = txtLeyExistente.Text;
            for (int k = 0; k < listaDeLeyes.cima2; k++)
            {
                if (LeyEliminada == listaDeLeyes.Leyes[k].nomLey)
                {
                    listaDeLeyes.Remove(k);
                    MessageBox.Show("Eliminado");
                    pnLeyes.Visible = false;
                    pnUsuario.Visible = true;
                    btnLogout.Visible = true;
                    btnModificarU.Visible = true;
                    btnEliminarU.Visible = true;
                    btnAgregarLeyes.Visible = true;
                    button1.Visible = true;


                    botonCantRe = 0;
                    lblCantidadReglamentos.Visible = true;
                    mTxtCantRegla.Clear();
                    mTxtCantRegla.Visible = true;
                    btnGuardarCantRegla.Visible = true;
                    lblReglamento.Visible = true;
                    txtReglamento.Visible = true;
                    btnGuardarRegla.Visible = true;
                    btnLeyCreada.Visible = true;
                    rbtnLeyNueva.Visible = true;
                    rbtnLeyNueva.Checked = false;
                    txtLeyNueva.Visible = true;
                    txtLeyNueva.Clear();
                    txtLeyExistente.Visible = true;
                    txtLeyExistente.Clear();
                    rLblLeyExistente.Visible = true;
                    rLblLeyExistente.Checked = false;
                    btnAgregarLeyExistente.Visible = true;
                    btnModLey.Visible = true;
                    btnEliminarLey.Visible = true;
                    btnGuardarLey.Visible = true;

                }
                if (k == listaUsuarios.limite - 1)
                {
                    MessageBox.Show("No Existe");
                }
            }
            MessageBox.Show("No Existe :)");

        }



       }
}
