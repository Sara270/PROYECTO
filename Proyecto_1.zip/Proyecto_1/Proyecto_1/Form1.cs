﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listaUsuarios = new ListaUser();
        }
        public ListaUser listaUsuarios;
        
        public Lista listaAsesor;
        Usuarios us;

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            for (int j = 0; j < listaUsuarios.cima; j++)
            {
                if (this.txtNombre.Text == listaUsuarios.Usuarios[j].nombre)
                {
                    if (this.txtContra.Text == listaUsuarios.Usuarios[j].contraseña)
                    {
                        MessageBox.Show("Bienvenido: " + listaUsuarios.Usuarios[j].nombre);
                        pnUsuario.Visible = true;
                        pnInicio.Visible = false;
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Contraseña Incorrecta");
                    }
                }
                if (j == listaUsuarios.limite - 1)
                {
                    MessageBox.Show("No Existe");
                }
            }
            MessageBox.Show("No Existe :)");
           
        }
        int boton2=0;
        private void btnCreate_Click(object sender, EventArgs e)
        {
            pnInicio.Hide();
            if (boton2 < 9)
            {
                lblDip.Visible = true;
                txtNombreDip.Clear();
                txtNombreDip.Visible = true;
                btnNom.Visible = true;

                boton = 0;
                lblCantA.Visible = true;
                mTxtCasesores.Clear();
                mTxtCasesores.Visible = true;
                GuardarCantAsesor.Visible = true;

                btnContra.Visible=true;
                lblContra.Visible = true;
                txtContraseña.Clear();
                txtContraseña.Visible=true;

                lblNomA.Visible = true;
                btnGuardarAse.Visible = true;
                txtNomAsesor.Clear();
                txtNomAsesor.Visible = true;



                pnCreate.Visible = true;
                boton2++;
            }
            else
            {
                MessageBox.Show("No caben más Usuarios");
            }         
            
            
        }
       
        private void btnNom_Click(object sender, EventArgs e)
        {
            lblDip.Visible = false;
            txtNombreDip.Visible = false;
            btnNom.Visible = false;

        }

        private void GuardarCantAsesor_Click(object sender, EventArgs e)
        {
            int c;
            c = int.Parse(mTxtCasesores.Text);
            lblCantA.Visible = false;
            mTxtCasesores.Visible = false;
            GuardarCantAsesor.Visible = false;
            listaAsesor = new Lista(true, int.Parse(mTxtCasesores.Text));

        }
        int boton = 0;

        private void btnGuardarAse_Click(object sender, EventArgs e)
        {
            int c;
            c = int.Parse(mTxtCasesores.Text);
            string nomAsesor;
            boton++;
            nomAsesor = txtNomAsesor.Text;
            listaAsesor.Add_Asesor(nomAsesor);
            if (c == boton)
            {
                lblNomA.Visible = false;
                btnGuardarAse.Visible = false;
                txtNomAsesor.Visible = false;
            }
            txtNomAsesor.Clear();
        }

        private void btnContra_Click(object sender, EventArgs e)
        {
            btnContra.Hide();
            lblContra.Hide();
            txtContraseña.Hide();
        }

        private void btnCreado_Click(object sender, EventArgs e)
        {
            string nom;
            int numAse;
            nom = txtNombreDip.Text;
            string contraseña;
            contraseña = txtContraseña.Text;
            numAse = int.Parse(mTxtCasesores.Text);
            us = new Usuarios(nom, numAse, listaAsesor, contraseña);
            Recibe();
            pnUsuario.Visible = true;
            /////// btnCreado = false
            pnCreate.Visible = false;
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            pnUsuario.Visible = false;
            pnInicio.Visible = true;

        }

        public Usuarios RetornoDatosUs()
        {
          //  us.listaAsesor = this.listaAsesor;
            return us;
        }
        public void Recibe()
        {
            Usuarios nuevo;
            nuevo = RetornoDatosUs();
            listaUsuarios.Add_Usuarios(nuevo);
        }

        private void btnEliminarU_Click(object sender, EventArgs e)
        {

            pnInicio.Visible = false;
            pnUsuario.Visible = false;
            pnCreate.Visible = false;
            pnElimina.Visible = true;
        }

        private void btnEliminado_Click(object sender, EventArgs e)
        {
            string UserR;
            UserR=txtNomEliminar.Text;
             for (int k = 0; k < listaUsuarios.cima; k++)
            {
                if (UserR == listaUsuarios.Usuarios[k].nombre)
                {
                   listaUsuarios.Remove(k);
                   MessageBox.Show("Eliminado");
                   pnElimina.Visible = false;
                   pnInicio.Visible = true;
                }
                if (k == listaUsuarios.limite - 1)
                {
                    MessageBox.Show("No Existe");
                }
            }
            MessageBox.Show("No Existe :)");
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

    }
}
