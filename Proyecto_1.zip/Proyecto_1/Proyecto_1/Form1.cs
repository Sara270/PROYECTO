﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listaUsuarios = new ListaUser();
        }
        public ListaUser listaUsuarios;
        
        public Lista listaAsesor;
        Usuarios us;

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            for (int j = 0; j < listaUsuarios.cima; j++)
            {
                if (this.txtNombre.Text == listaUsuarios.Usuarios[j].nombre)
                {
                    if (this.txtContra.Text == listaUsuarios.Usuarios[j].contraseña)
                    {
                        MessageBox.Show("Bienvenido: " + listaUsuarios.Usuarios[j].nombre);
                        pnUsuario.Visible = true;
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Contraseña Incorrecta");
                    }
                }
                if (j == listaUsuarios.limite - 1)
                {
                    MessageBox.Show("No Existe");
                }
            }
            MessageBox.Show("No Existe");
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            pnInicio.Hide();
            pnCreate.Visible=true;
            Recibe();
        }
        public void Recibe()
        {

            listaUsuarios.Add_Usuarios(us);
        }

        private void btnNom_Click(object sender, EventArgs e)
        {
            lblDip.Visible = false;
            txtNombreDip.Visible = false;
            btnNom.Visible = false;

        }

        private void GuardarCantAsesor_Click(object sender, EventArgs e)
        {
            int c;
            c = int.Parse(mTxtCasesores.Text);
            lblCantA.Visible = false;
            mTxtCasesores.Visible = false;
            GuardarCantAsesor.Visible = false;
            listaAsesor = new Lista(true, int.Parse(mTxtCasesores.Text));

        }
        int boton = 0;

        private void btnGuardarAse_Click(object sender, EventArgs e)
        {
            int c;
            c = int.Parse(mTxtCasesores.Text);
            string nomAsesor;
            boton++;
            nomAsesor = txtNomAsesor.Text;
            listaAsesor.Add_Asesor(nomAsesor);
            if (c == boton)
            {
                lblNomA.Visible = false;
                btnGuardarAse.Visible = false;
                txtNomAsesor.Visible = false;
            }
            txtNomAsesor.Clear();
        }

        private void btnContra_Click(object sender, EventArgs e)
        {
            btnContra.Hide();
            lblContra.Hide();
            txtContraseña.Hide();
        }

        private void btnCreado_Click(object sender, EventArgs e)
        {
            string nom;
            int numAse;
            nom = txtNombreDip.Text;
            string contraseña;
            contraseña = txtContra.Text;
            numAse = int.Parse(mTxtCasesores.Text);
            us = new Usuarios(nom, numAse, listaAsesor, contraseña);
            RetornoDatosUs();
            pnUsuario.Visible = true;
            btnCreado.Visible = false;
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            pnUsuario.Visible = false;
            pnInicio.Visible = true;

        }

        public Usuarios RetornoDatosUs()
        {
            return us;
        }
       

    }
}
