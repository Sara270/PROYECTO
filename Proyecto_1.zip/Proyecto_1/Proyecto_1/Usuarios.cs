﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_1
{
    public class Usuarios
    {
      
        public Lista ListaAsesorDentroUsuario;
        public string nombre;
        public string [] nombreAse;
        private string password;
        public ListaLeyes listadoLeyes;
        int asesoresc;
        /// <summary>
        /// Clase Usuarios que posee un metodo constructor "Usuarios"
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="asesoresc"></param>
        /// <param name="nombreAse"></param>
        /// <param name="contra"></param>
        /// <param name="lis"></param>
        public Usuarios (string nombre, int asesoresc, Lista nombreAse,  string contra, ListaLeyes lis){
            this.nombre = nombre;
            this.asesoresc = asesoresc;
            this.ListaAsesorDentroUsuario = nombreAse;
            this.password = contra;
            this.listadoLeyes = lis;
    }
        public void AgregaLeyes(Ley e)
        {
            listadoLeyes.Add_Leyes(e);
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public string contraseña1
        {
            get { return password; }
            set { password = value; }
        }
        
    }
}
