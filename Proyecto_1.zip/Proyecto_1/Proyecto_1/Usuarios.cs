﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_1
{
    public class Usuarios
    {
       // private Ley [] Leyes;
        public Lista listaAsesor;
        public string nombre;
        public string [] nombreAse;
        public string contraseña;
        public ListaLeyes listadoLeyes;
        //private Lista [] listau;
        int asesoresc;
        public Usuarios (string nombre, int asesoresc, Lista nombreAse,  string contra, ListaLeyes lis){
            this.nombre = nombre;
            this.asesoresc = asesoresc;
            this.listaAsesor = nombreAse;
            this.contraseña = contra;
            this.listadoLeyes = lis;
    }


        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        

        //public void ArregloAsesor()
        //{
        //    listaAsesor = new Lista(true, asesoresc);
        //    for (int i = 0; i < asesoresc; i++)
        //    {
        //        listaAsesor.Add_Asesor(nombreAse);
        //    }
               
        //}


    
    }
}
