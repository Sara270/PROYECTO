﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_1
{
    public class Asesores
    {
        public string nombre;
        public ListaLeyes listadoLeyesAsesores;
        public Asesores(string nombreA, ListaLeyes lis)
        {
            this.nombre = nombreA;
            this.listadoLeyesAsesores = lis;
        }
        public void AgregaLeyes(Ley e)
        {
            listadoLeyesAsesores.Add_Leyes(e);
        }
    }
}
