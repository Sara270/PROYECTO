﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_1
{
   public class Lista
    {
        public string[] listaAsesor;
        //private Ley[] listaLeyes;
        private int cima = -1;
        private int limite;
        private bool vacio;
        private bool lleno;
        
        private string[] listaReglamentos;
        
        /////////////////////////////////
        private string valor;
        private string valor2;


        public Lista(bool Diferenciar, int cantidadA, int cantidadReglamentos)
        {
            if (Diferenciar == true)
            { /// no es necesario el true
                listaAsesor = new string[cantidadA];
                limite = cantidadA;
            }
            else
            {
                listaReglamentos = new string[cantidadReglamentos];
                limite = cantidadReglamentos;
            }
            
        }

        private bool Valida_vacia_Asesor()
        {
            if (listaAsesor[0] == default(string))
            {
                vacio = true;
            }
            else
            {
                vacio = false;
            }
            return vacio;
        }

        private bool Valida_vacia_Reglamentos()
        {
            if (listaReglamentos[0] == default(string))
            {
                vacio = true;
            }
            else
            {
                vacio = false;
            }
            return vacio;
        }

        private bool Valida_lleno_Asesor()
        {
            if (listaAsesor[0] != default(string))
            {
                lleno = true;
            }
            else
            {
                lleno = false;
            }
            return lleno;
        }

        private bool Valida_lleno_Reglamentos()
        {
            if (listaReglamentos[0] != default(string))
            {
                lleno = true;
            }
            else
            {
                lleno = false;
            }
            return lleno;
        }

        public void Add_Asesor(string d)
        {
            if (Valida_vacia_Asesor() && cima < 0)
            {
                listaAsesor[0] = d;
                cima++;
            }
            else
            {
                if (cima < limite)
                {
                    cima++;
                    listaAsesor[cima] = d;
                }
            }
        }
        public void Add_Reglamentos(string e)
        {
            if (Valida_vacia_Reglamentos() && cima < 0)
            {
                listaReglamentos[0] = e;
                cima++;
            }
            else
            {
                if (cima < limite)
                {
                    cima++;
                    listaReglamentos[cima] = e;
                }
            }
        }

        // Revisar 

        public string Remove(int puntero)
        {
            if (Valida_lleno_Asesor() && puntero <= cima)
            {
                if (puntero == cima)
                {
                    valor = listaAsesor[puntero];
                    listaAsesor[cima] = default(string);
                    cima--;
                }
                else
                {
                    valor = listaAsesor[puntero];
                    for (int i = puntero; i < cima; i++)
                    {
                        listaAsesor[i] = listaAsesor[i + 1];
                    }
                    listaAsesor[cima] = default(string);
                    cima--;
                }
            }
            else
            {
                Console.WriteLine("La lista no posee valor en la posicion especificada");
            }
            return valor;
        }

        public string Remove1(int puntero1)
        {
            if (Valida_lleno_Reglamentos() && puntero1 <= cima)
            {
                if (puntero1 == cima)
                {
                    valor2 = listaReglamentos[puntero1];
                    listaReglamentos[cima] = default(string);
                    cima--;
                }
                else
                {
                    valor2 = listaReglamentos[puntero1];
                    for (int i = puntero1; i < cima; i++)
                    {
                        listaReglamentos[i] = listaReglamentos[i + 1];
                    }
                    listaReglamentos[cima] = default(string);
                    cima--;
                }
            }
            else
            {
                Console.WriteLine("La lista no posee valor en la posicion especificada");
            }
            return valor2;
        }
    }
}
