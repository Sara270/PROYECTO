﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_1
{
    public class Ley
    {
        private Lista listaReglamentos;
        public string nomLey;
        private int cantReglamentos;

        public Ley(string nL, int cRegla, Lista nomRegla)
        {
            this.nomLey = nL;
            this.listaReglamentos = nomRegla;
            this.cantReglamentos = cRegla;
        }

    }
}
