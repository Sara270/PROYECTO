﻿namespace Proyecto_1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnInicio = new System.Windows.Forms.Panel();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnLogIn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtContra = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnCreate = new System.Windows.Forms.Panel();
            this.txtContraseña = new System.Windows.Forms.TextBox();
            this.lblContra = new System.Windows.Forms.Label();
            this.btnContra = new System.Windows.Forms.Button();
            this.btnNom = new System.Windows.Forms.Button();
            this.GuardarCantAsesor = new System.Windows.Forms.Button();
            this.mTxtCasesores = new System.Windows.Forms.MaskedTextBox();
            this.lblCantA = new System.Windows.Forms.Label();
            this.btnGuardarAse = new System.Windows.Forms.Button();
            this.txtNomAsesor = new System.Windows.Forms.TextBox();
            this.lblNomA = new System.Windows.Forms.Label();
            this.btnCreado = new System.Windows.Forms.Button();
            this.txtNombreDip = new System.Windows.Forms.TextBox();
            this.lblDip = new System.Windows.Forms.Label();
            this.pnUsuario = new System.Windows.Forms.Panel();
            this.btnEliminarU = new System.Windows.Forms.Button();
            this.btnModificarU = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnAgregarLeyes = new System.Windows.Forms.Button();
            this.pnInicio.SuspendLayout();
            this.pnCreate.SuspendLayout();
            this.pnUsuario.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnInicio
            // 
            this.pnInicio.Controls.Add(this.btnCreate);
            this.pnInicio.Controls.Add(this.btnLogIn);
            this.pnInicio.Controls.Add(this.label1);
            this.pnInicio.Controls.Add(this.txtContra);
            this.pnInicio.Controls.Add(this.txtNombre);
            this.pnInicio.Controls.Add(this.label3);
            this.pnInicio.Controls.Add(this.label2);
            this.pnInicio.Location = new System.Drawing.Point(12, 12);
            this.pnInicio.Name = "pnInicio";
            this.pnInicio.Size = new System.Drawing.Size(278, 210);
            this.pnInicio.TabIndex = 1;
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(158, 175);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(75, 23);
            this.btnCreate.TabIndex = 8;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnLogIn
            // 
            this.btnLogIn.Location = new System.Drawing.Point(47, 175);
            this.btnLogIn.Name = "btnLogIn";
            this.btnLogIn.Size = new System.Drawing.Size(75, 23);
            this.btnLogIn.TabIndex = 7;
            this.btnLogIn.Text = "LogIn";
            this.btnLogIn.UseVisualStyleBackColor = true;
            this.btnLogIn.Click += new System.EventHandler(this.btnLogIn_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Haettenschweiler", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 55);
            this.label1.TabIndex = 6;
            this.label1.Text = "SISLEY";
            // 
            // txtContra
            // 
            this.txtContra.Location = new System.Drawing.Point(31, 133);
            this.txtContra.Name = "txtContra";
            this.txtContra.Size = new System.Drawing.Size(138, 20);
            this.txtContra.TabIndex = 5;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(31, 79);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(150, 20);
            this.txtNombre.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("AR CENA", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 19);
            this.label3.TabIndex = 3;
            this.label3.Text = "Contraseña";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("AR CENA", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Usuario";
            // 
            // pnCreate
            // 
            this.pnCreate.Controls.Add(this.txtContraseña);
            this.pnCreate.Controls.Add(this.lblContra);
            this.pnCreate.Controls.Add(this.btnContra);
            this.pnCreate.Controls.Add(this.btnNom);
            this.pnCreate.Controls.Add(this.GuardarCantAsesor);
            this.pnCreate.Controls.Add(this.mTxtCasesores);
            this.pnCreate.Controls.Add(this.lblCantA);
            this.pnCreate.Controls.Add(this.btnGuardarAse);
            this.pnCreate.Controls.Add(this.txtNomAsesor);
            this.pnCreate.Controls.Add(this.lblNomA);
            this.pnCreate.Controls.Add(this.btnCreado);
            this.pnCreate.Controls.Add(this.txtNombreDip);
            this.pnCreate.Controls.Add(this.lblDip);
            this.pnCreate.Location = new System.Drawing.Point(296, 12);
            this.pnCreate.Name = "pnCreate";
            this.pnCreate.Size = new System.Drawing.Size(417, 175);
            this.pnCreate.TabIndex = 19;
            this.pnCreate.Visible = false;
            // 
            // txtContraseña
            // 
            this.txtContraseña.Location = new System.Drawing.Point(225, 19);
            this.txtContraseña.Name = "txtContraseña";
            this.txtContraseña.Size = new System.Drawing.Size(100, 20);
            this.txtContraseña.TabIndex = 17;
            // 
            // lblContra
            // 
            this.lblContra.AutoSize = true;
            this.lblContra.Location = new System.Drawing.Point(226, 3);
            this.lblContra.Name = "lblContra";
            this.lblContra.Size = new System.Drawing.Size(99, 13);
            this.lblContra.TabIndex = 16;
            this.lblContra.Text = "Ingrese Contraseña";
            // 
            // btnContra
            // 
            this.btnContra.Location = new System.Drawing.Point(331, 17);
            this.btnContra.Name = "btnContra";
            this.btnContra.Size = new System.Drawing.Size(75, 23);
            this.btnContra.TabIndex = 15;
            this.btnContra.Text = "Guardar";
            this.btnContra.UseVisualStyleBackColor = true;
            this.btnContra.Click += new System.EventHandler(this.btnContra_Click);
            // 
            // btnNom
            // 
            this.btnNom.Location = new System.Drawing.Point(115, 16);
            this.btnNom.Name = "btnNom";
            this.btnNom.Size = new System.Drawing.Size(75, 23);
            this.btnNom.TabIndex = 14;
            this.btnNom.Text = "Guardar";
            this.btnNom.UseVisualStyleBackColor = true;
            this.btnNom.Click += new System.EventHandler(this.btnNom_Click);
            // 
            // GuardarCantAsesor
            // 
            this.GuardarCantAsesor.Location = new System.Drawing.Point(115, 67);
            this.GuardarCantAsesor.Name = "GuardarCantAsesor";
            this.GuardarCantAsesor.Size = new System.Drawing.Size(75, 23);
            this.GuardarCantAsesor.TabIndex = 12;
            this.GuardarCantAsesor.Text = "Guardar";
            this.GuardarCantAsesor.UseVisualStyleBackColor = true;
            this.GuardarCantAsesor.Click += new System.EventHandler(this.GuardarCantAsesor_Click);
            // 
            // mTxtCasesores
            // 
            this.mTxtCasesores.Location = new System.Drawing.Point(9, 67);
            this.mTxtCasesores.Mask = "99999";
            this.mTxtCasesores.Name = "mTxtCasesores";
            this.mTxtCasesores.Size = new System.Drawing.Size(81, 20);
            this.mTxtCasesores.TabIndex = 11;
            this.mTxtCasesores.ValidatingType = typeof(int);
            // 
            // lblCantA
            // 
            this.lblCantA.AutoSize = true;
            this.lblCantA.Location = new System.Drawing.Point(6, 51);
            this.lblCantA.Name = "lblCantA";
            this.lblCantA.Size = new System.Drawing.Size(133, 13);
            this.lblCantA.TabIndex = 10;
            this.lblCantA.Text = "Ingrese Cantidad Asesores";
            // 
            // btnGuardarAse
            // 
            this.btnGuardarAse.Location = new System.Drawing.Point(115, 118);
            this.btnGuardarAse.Name = "btnGuardarAse";
            this.btnGuardarAse.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarAse.TabIndex = 9;
            this.btnGuardarAse.Text = "Guardar";
            this.btnGuardarAse.UseVisualStyleBackColor = true;
            this.btnGuardarAse.Click += new System.EventHandler(this.btnGuardarAse_Click);
            // 
            // txtNomAsesor
            // 
            this.txtNomAsesor.Location = new System.Drawing.Point(9, 118);
            this.txtNomAsesor.Name = "txtNomAsesor";
            this.txtNomAsesor.Size = new System.Drawing.Size(100, 20);
            this.txtNomAsesor.TabIndex = 8;
            // 
            // lblNomA
            // 
            this.lblNomA.AutoSize = true;
            this.lblNomA.Location = new System.Drawing.Point(6, 102);
            this.lblNomA.Name = "lblNomA";
            this.lblNomA.Size = new System.Drawing.Size(79, 13);
            this.lblNomA.TabIndex = 7;
            this.lblNomA.Text = "Nombre Asesor";
            // 
            // btnCreado
            // 
            this.btnCreado.Location = new System.Drawing.Point(241, 72);
            this.btnCreado.Name = "btnCreado";
            this.btnCreado.Size = new System.Drawing.Size(103, 43);
            this.btnCreado.TabIndex = 4;
            this.btnCreado.Text = "Create";
            this.btnCreado.UseVisualStyleBackColor = true;
            this.btnCreado.Click += new System.EventHandler(this.btnCreado_Click);
            // 
            // txtNombreDip
            // 
            this.txtNombreDip.Location = new System.Drawing.Point(9, 19);
            this.txtNombreDip.Name = "txtNombreDip";
            this.txtNombreDip.Size = new System.Drawing.Size(100, 20);
            this.txtNombreDip.TabIndex = 2;
            // 
            // lblDip
            // 
            this.lblDip.AutoSize = true;
            this.lblDip.Location = new System.Drawing.Point(6, 3);
            this.lblDip.Name = "lblDip";
            this.lblDip.Size = new System.Drawing.Size(88, 13);
            this.lblDip.TabIndex = 0;
            this.lblDip.Text = "Ingrese Nombre: ";
            // 
            // pnUsuario
            // 
            this.pnUsuario.Controls.Add(this.button1);
            this.pnUsuario.Controls.Add(this.btnEliminarU);
            this.pnUsuario.Controls.Add(this.btnAgregarLeyes);
            this.pnUsuario.Controls.Add(this.btnLogout);
            this.pnUsuario.Controls.Add(this.btnModificarU);
            this.pnUsuario.Location = new System.Drawing.Point(296, 193);
            this.pnUsuario.Name = "pnUsuario";
            this.pnUsuario.Size = new System.Drawing.Size(344, 120);
            this.pnUsuario.TabIndex = 20;
            this.pnUsuario.Visible = false;
            // 
            // btnEliminarU
            // 
            this.btnEliminarU.Location = new System.Drawing.Point(225, 6);
            this.btnEliminarU.Name = "btnEliminarU";
            this.btnEliminarU.Size = new System.Drawing.Size(75, 34);
            this.btnEliminarU.TabIndex = 5;
            this.btnEliminarU.Text = "Eliminar Usuario";
            this.btnEliminarU.UseVisualStyleBackColor = true;
            // 
            // btnModificarU
            // 
            this.btnModificarU.Location = new System.Drawing.Point(115, 6);
            this.btnModificarU.Name = "btnModificarU";
            this.btnModificarU.Size = new System.Drawing.Size(75, 34);
            this.btnModificarU.TabIndex = 4;
            this.btnModificarU.Text = "Modificar Usuario";
            this.btnModificarU.UseVisualStyleBackColor = true;
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(10, 6);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 1;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(212, 56);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 52);
            this.button1.TabIndex = 4;
            this.button1.Text = "Insertar Leyes";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnAgregarLeyes
            // 
            this.btnAgregarLeyes.Location = new System.Drawing.Point(76, 56);
            this.btnAgregarLeyes.Name = "btnAgregarLeyes";
            this.btnAgregarLeyes.Size = new System.Drawing.Size(113, 52);
            this.btnAgregarLeyes.TabIndex = 2;
            this.btnAgregarLeyes.Text = "Ver Leyes";
            this.btnAgregarLeyes.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 501);
            this.Controls.Add(this.pnUsuario);
            this.Controls.Add(this.pnCreate);
            this.Controls.Add(this.pnInicio);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnInicio.ResumeLayout(false);
            this.pnInicio.PerformLayout();
            this.pnCreate.ResumeLayout(false);
            this.pnCreate.PerformLayout();
            this.pnUsuario.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnInicio;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnLogIn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtContra;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnCreate;
        private System.Windows.Forms.TextBox txtContraseña;
        private System.Windows.Forms.Label lblContra;
        private System.Windows.Forms.Button btnContra;
        private System.Windows.Forms.Button btnNom;
        private System.Windows.Forms.Button GuardarCantAsesor;
        private System.Windows.Forms.MaskedTextBox mTxtCasesores;
        private System.Windows.Forms.Label lblCantA;
        private System.Windows.Forms.Button btnGuardarAse;
        private System.Windows.Forms.TextBox txtNomAsesor;
        private System.Windows.Forms.Label lblNomA;
        private System.Windows.Forms.Button btnCreado;
        private System.Windows.Forms.TextBox txtNombreDip;
        private System.Windows.Forms.Label lblDip;
        private System.Windows.Forms.Panel pnUsuario;
        private System.Windows.Forms.Button btnEliminarU;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnModificarU;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnAgregarLeyes;
    }
}

