﻿namespace Proyecto_1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnInicio = new System.Windows.Forms.Panel();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnLogIn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtContra = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnCreate = new System.Windows.Forms.Panel();
            this.btnSiguiente = new System.Windows.Forms.Button();
            this.lblMake = new System.Windows.Forms.Label();
            this.txtContraseña = new System.Windows.Forms.TextBox();
            this.lblContra = new System.Windows.Forms.Label();
            this.btnContra = new System.Windows.Forms.Button();
            this.btnNom = new System.Windows.Forms.Button();
            this.GuardarCantAsesor = new System.Windows.Forms.Button();
            this.mTxtCasesores = new System.Windows.Forms.MaskedTextBox();
            this.lblCantA = new System.Windows.Forms.Label();
            this.btnGuardarAse = new System.Windows.Forms.Button();
            this.txtNomAsesor = new System.Windows.Forms.TextBox();
            this.lblNomA = new System.Windows.Forms.Label();
            this.txtNombreDip = new System.Windows.Forms.TextBox();
            this.lblDip = new System.Windows.Forms.Label();
            this.btnCreado = new System.Windows.Forms.Button();
            this.pnUsuario = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.lblPerfil = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnEliminarU = new System.Windows.Forms.Button();
            this.btnAgregarLeyes = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnModificarU = new System.Windows.Forms.Button();
            this.btnFunciones = new System.Windows.Forms.Button();
            this.pnElimina = new System.Windows.Forms.Panel();
            this.btnEliminado = new System.Windows.Forms.Button();
            this.txtNomEliminar = new System.Windows.Forms.TextBox();
            this.lblEliminacion = new System.Windows.Forms.Label();
            this.pnModificar = new System.Windows.Forms.Panel();
            this.btnModificado = new System.Windows.Forms.Button();
            this.txtUsuarioModificar = new System.Windows.Forms.TextBox();
            this.lblModificar = new System.Windows.Forms.Label();
            this.pnLeyes = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.btnprest = new System.Windows.Forms.Button();
            this.lblLeyMod = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rbtnLeyNueva = new System.Windows.Forms.RadioButton();
            this.rLblLeyExistente = new System.Windows.Forms.RadioButton();
            this.btnEliminarLey = new System.Windows.Forms.Button();
            this.btnModLey = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnGuardarRegla = new System.Windows.Forms.Button();
            this.btnGuardarLey = new System.Windows.Forms.Button();
            this.lblReglamento = new System.Windows.Forms.Label();
            this.txtReglamento = new System.Windows.Forms.TextBox();
            this.btnGuardarCantRegla = new System.Windows.Forms.Button();
            this.mTxtCantRegla = new System.Windows.Forms.MaskedTextBox();
            this.lblCantidadReglamentos = new System.Windows.Forms.Label();
            this.btnLeyCreada = new System.Windows.Forms.Button();
            this.btnAgregarLeyExistente = new System.Windows.Forms.Button();
            this.txtLeyNueva = new System.Windows.Forms.TextBox();
            this.txtLeyExistente = new System.Windows.Forms.TextBox();
            this.pnDevolver = new System.Windows.Forms.Panel();
            this.lblDevolver = new System.Windows.Forms.Label();
            this.txtDevolver = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.pnInformes = new System.Windows.Forms.Panel();
            this.btnInformeGrupo = new System.Windows.Forms.Button();
            this.btnInformeLey = new System.Windows.Forms.Button();
            this.DGVMuestraLeyes = new System.Windows.Forms.DataGridView();
            this.pnReglamento = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.lblNomLeyRegla = new System.Windows.Forms.Label();
            this.txtModRegla = new System.Windows.Forms.TextBox();
            this.btnEliminarReglamento = new System.Windows.Forms.Button();
            this.btnGuardarReglaMod = new System.Windows.Forms.Button();
            this.txtNewName = new System.Windows.Forms.TextBox();
            this.btnModificarRegla = new System.Windows.Forms.Button();
            this.txtReglaAMod = new System.Windows.Forms.TextBox();
            this.lblReglaModi = new System.Windows.Forms.Label();
            this.pnInicio.SuspendLayout();
            this.pnCreate.SuspendLayout();
            this.pnUsuario.SuspendLayout();
            this.pnElimina.SuspendLayout();
            this.pnModificar.SuspendLayout();
            this.pnLeyes.SuspendLayout();
            this.pnDevolver.SuspendLayout();
            this.pnInformes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVMuestraLeyes)).BeginInit();
            this.pnReglamento.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnInicio
            // 
            this.pnInicio.BackColor = System.Drawing.Color.CadetBlue;
            this.pnInicio.Controls.Add(this.btnCreate);
            this.pnInicio.Controls.Add(this.btnLogIn);
            this.pnInicio.Controls.Add(this.label1);
            this.pnInicio.Controls.Add(this.txtContra);
            this.pnInicio.Controls.Add(this.txtNombre);
            this.pnInicio.Controls.Add(this.label3);
            this.pnInicio.Controls.Add(this.label2);
            this.pnInicio.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnInicio.Location = new System.Drawing.Point(12, 12);
            this.pnInicio.Name = "pnInicio";
            this.pnInicio.Size = new System.Drawing.Size(278, 210);
            this.pnInicio.TabIndex = 1;
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(158, 175);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(75, 23);
            this.btnCreate.TabIndex = 8;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnLogIn
            // 
            this.btnLogIn.Location = new System.Drawing.Point(47, 175);
            this.btnLogIn.Name = "btnLogIn";
            this.btnLogIn.Size = new System.Drawing.Size(75, 23);
            this.btnLogIn.TabIndex = 7;
            this.btnLogIn.Text = "LogIn";
            this.btnLogIn.UseVisualStyleBackColor = true;
            this.btnLogIn.Click += new System.EventHandler(this.btnLogIn_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Haettenschweiler", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 55);
            this.label1.TabIndex = 6;
            this.label1.Text = "SISLEY";
            // 
            // txtContra
            // 
            this.txtContra.Location = new System.Drawing.Point(31, 133);
            this.txtContra.Name = "txtContra";
            this.txtContra.Size = new System.Drawing.Size(138, 20);
            this.txtContra.TabIndex = 5;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(31, 79);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(150, 20);
            this.txtNombre.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("AR CENA", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 19);
            this.label3.TabIndex = 3;
            this.label3.Text = "Contraseña";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("AR CENA", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Usuario";
            // 
            // pnCreate
            // 
            this.pnCreate.BackColor = System.Drawing.Color.MediumAquamarine;
            this.pnCreate.Controls.Add(this.btnSiguiente);
            this.pnCreate.Controls.Add(this.lblMake);
            this.pnCreate.Controls.Add(this.txtContraseña);
            this.pnCreate.Controls.Add(this.lblContra);
            this.pnCreate.Controls.Add(this.btnContra);
            this.pnCreate.Controls.Add(this.btnNom);
            this.pnCreate.Controls.Add(this.GuardarCantAsesor);
            this.pnCreate.Controls.Add(this.mTxtCasesores);
            this.pnCreate.Controls.Add(this.lblCantA);
            this.pnCreate.Controls.Add(this.btnGuardarAse);
            this.pnCreate.Controls.Add(this.txtNomAsesor);
            this.pnCreate.Controls.Add(this.lblNomA);
            this.pnCreate.Controls.Add(this.txtNombreDip);
            this.pnCreate.Controls.Add(this.lblDip);
            this.pnCreate.Location = new System.Drawing.Point(296, 3);
            this.pnCreate.Name = "pnCreate";
            this.pnCreate.Size = new System.Drawing.Size(417, 221);
            this.pnCreate.TabIndex = 19;
            this.pnCreate.Visible = false;
            // 
            // btnSiguiente
            // 
            this.btnSiguiente.Location = new System.Drawing.Point(255, 131);
            this.btnSiguiente.Name = "btnSiguiente";
            this.btnSiguiente.Size = new System.Drawing.Size(128, 28);
            this.btnSiguiente.TabIndex = 19;
            this.btnSiguiente.Text = "Siguiente";
            this.btnSiguiente.UseVisualStyleBackColor = true;
            this.btnSiguiente.Visible = false;
            this.btnSiguiente.Click += new System.EventHandler(this.btnSiguiente_Click);
            // 
            // lblMake
            // 
            this.lblMake.Font = new System.Drawing.Font("Haettenschweiler", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMake.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblMake.Location = new System.Drawing.Point(3, 6);
            this.lblMake.Name = "lblMake";
            this.lblMake.Size = new System.Drawing.Size(406, 55);
            this.lblMake.TabIndex = 18;
            this.lblMake.Text = "MAKE YOUR OWN USER!";
            this.lblMake.Click += new System.EventHandler(this.label4_Click);
            // 
            // txtContraseña
            // 
            this.txtContraseña.Location = new System.Drawing.Point(226, 91);
            this.txtContraseña.Name = "txtContraseña";
            this.txtContraseña.Size = new System.Drawing.Size(100, 20);
            this.txtContraseña.TabIndex = 17;
            // 
            // lblContra
            // 
            this.lblContra.AutoSize = true;
            this.lblContra.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContra.Location = new System.Drawing.Point(222, 66);
            this.lblContra.Name = "lblContra";
            this.lblContra.Size = new System.Drawing.Size(117, 20);
            this.lblContra.TabIndex = 16;
            this.lblContra.Text = "Ingrese Contraseña";
            // 
            // btnContra
            // 
            this.btnContra.Location = new System.Drawing.Point(332, 89);
            this.btnContra.Name = "btnContra";
            this.btnContra.Size = new System.Drawing.Size(75, 23);
            this.btnContra.TabIndex = 15;
            this.btnContra.Text = "Guardar";
            this.btnContra.UseVisualStyleBackColor = true;
            this.btnContra.Click += new System.EventHandler(this.btnContra_Click);
            // 
            // btnNom
            // 
            this.btnNom.Location = new System.Drawing.Point(116, 88);
            this.btnNom.Name = "btnNom";
            this.btnNom.Size = new System.Drawing.Size(75, 23);
            this.btnNom.TabIndex = 14;
            this.btnNom.Text = "Guardar";
            this.btnNom.UseVisualStyleBackColor = true;
            this.btnNom.Click += new System.EventHandler(this.btnNom_Click);
            // 
            // GuardarCantAsesor
            // 
            this.GuardarCantAsesor.Location = new System.Drawing.Point(116, 139);
            this.GuardarCantAsesor.Name = "GuardarCantAsesor";
            this.GuardarCantAsesor.Size = new System.Drawing.Size(75, 23);
            this.GuardarCantAsesor.TabIndex = 12;
            this.GuardarCantAsesor.Text = "Guardar";
            this.GuardarCantAsesor.UseVisualStyleBackColor = true;
            this.GuardarCantAsesor.Click += new System.EventHandler(this.GuardarCantAsesor_Click);
            // 
            // mTxtCasesores
            // 
            this.mTxtCasesores.Location = new System.Drawing.Point(10, 139);
            this.mTxtCasesores.Mask = "99999";
            this.mTxtCasesores.Name = "mTxtCasesores";
            this.mTxtCasesores.Size = new System.Drawing.Size(81, 20);
            this.mTxtCasesores.TabIndex = 11;
            this.mTxtCasesores.ValidatingType = typeof(int);
            // 
            // lblCantA
            // 
            this.lblCantA.AutoSize = true;
            this.lblCantA.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCantA.Location = new System.Drawing.Point(6, 116);
            this.lblCantA.Name = "lblCantA";
            this.lblCantA.Size = new System.Drawing.Size(156, 20);
            this.lblCantA.TabIndex = 10;
            this.lblCantA.Text = "Ingrese Cantidad Asesores";
            // 
            // btnGuardarAse
            // 
            this.btnGuardarAse.Location = new System.Drawing.Point(116, 190);
            this.btnGuardarAse.Name = "btnGuardarAse";
            this.btnGuardarAse.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarAse.TabIndex = 9;
            this.btnGuardarAse.Text = "Guardar";
            this.btnGuardarAse.UseVisualStyleBackColor = true;
            this.btnGuardarAse.Click += new System.EventHandler(this.btnGuardarAse_Click);
            // 
            // txtNomAsesor
            // 
            this.txtNomAsesor.Location = new System.Drawing.Point(10, 190);
            this.txtNomAsesor.Name = "txtNomAsesor";
            this.txtNomAsesor.Size = new System.Drawing.Size(100, 20);
            this.txtNomAsesor.TabIndex = 8;
            this.txtNomAsesor.TextChanged += new System.EventHandler(this.txtNomAsesor_TextChanged);
            // 
            // lblNomA
            // 
            this.lblNomA.AutoSize = true;
            this.lblNomA.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomA.Location = new System.Drawing.Point(6, 167);
            this.lblNomA.Name = "lblNomA";
            this.lblNomA.Size = new System.Drawing.Size(95, 20);
            this.lblNomA.TabIndex = 7;
            this.lblNomA.Text = "Nombre Asesor";
            // 
            // txtNombreDip
            // 
            this.txtNombreDip.Location = new System.Drawing.Point(10, 91);
            this.txtNombreDip.Name = "txtNombreDip";
            this.txtNombreDip.Size = new System.Drawing.Size(100, 20);
            this.txtNombreDip.TabIndex = 2;
            // 
            // lblDip
            // 
            this.lblDip.AutoSize = true;
            this.lblDip.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDip.Location = new System.Drawing.Point(6, 68);
            this.lblDip.Name = "lblDip";
            this.lblDip.Size = new System.Drawing.Size(104, 20);
            this.lblDip.TabIndex = 0;
            this.lblDip.Text = "Ingrese Nombre: ";
            // 
            // btnCreado
            // 
            this.btnCreado.Location = new System.Drawing.Point(420, 178);
            this.btnCreado.Name = "btnCreado";
            this.btnCreado.Size = new System.Drawing.Size(103, 118);
            this.btnCreado.TabIndex = 4;
            this.btnCreado.Text = "DONE!!";
            this.btnCreado.UseVisualStyleBackColor = true;
            this.btnCreado.Click += new System.EventHandler(this.btnCreado_Click);
            // 
            // pnUsuario
            // 
            this.pnUsuario.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnUsuario.Controls.Add(this.label4);
            this.pnUsuario.Controls.Add(this.lblPerfil);
            this.pnUsuario.Controls.Add(this.button1);
            this.pnUsuario.Controls.Add(this.btnEliminarU);
            this.pnUsuario.Controls.Add(this.btnAgregarLeyes);
            this.pnUsuario.Controls.Add(this.btnLogout);
            this.pnUsuario.Controls.Add(this.btnModificarU);
            this.pnUsuario.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnUsuario.Location = new System.Drawing.Point(552, 230);
            this.pnUsuario.Name = "pnUsuario";
            this.pnUsuario.Size = new System.Drawing.Size(357, 177);
            this.pnUsuario.TabIndex = 20;
            this.pnUsuario.Visible = false;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Haettenschweiler", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.label4.Location = new System.Drawing.Point(-157, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 62);
            this.label4.TabIndex = 19;
            this.label4.Text = "MAKE YOUR OWN USER!";
            // 
            // lblPerfil
            // 
            this.lblPerfil.Font = new System.Drawing.Font("Haettenschweiler", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPerfil.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblPerfil.Location = new System.Drawing.Point(106, 0);
            this.lblPerfil.Name = "lblPerfil";
            this.lblPerfil.Size = new System.Drawing.Size(143, 55);
            this.lblPerfil.TabIndex = 7;
            this.lblPerfil.Text = "PROFILE";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(193, 108);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 52);
            this.button1.TabIndex = 4;
            this.button1.Text = "Insertar Leyes";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnEliminarU
            // 
            this.btnEliminarU.Location = new System.Drawing.Point(240, 67);
            this.btnEliminarU.Name = "btnEliminarU";
            this.btnEliminarU.Size = new System.Drawing.Size(75, 34);
            this.btnEliminarU.TabIndex = 5;
            this.btnEliminarU.Text = "Eliminar Usuario";
            this.btnEliminarU.UseVisualStyleBackColor = true;
            this.btnEliminarU.Click += new System.EventHandler(this.btnEliminarU_Click);
            // 
            // btnAgregarLeyes
            // 
            this.btnAgregarLeyes.Location = new System.Drawing.Point(57, 108);
            this.btnAgregarLeyes.Name = "btnAgregarLeyes";
            this.btnAgregarLeyes.Size = new System.Drawing.Size(113, 52);
            this.btnAgregarLeyes.TabIndex = 2;
            this.btnAgregarLeyes.Text = "Ver Leyes";
            this.btnAgregarLeyes.UseVisualStyleBackColor = true;
            this.btnAgregarLeyes.Click += new System.EventHandler(this.btnAgregarLeyes_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(25, 67);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 1;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnModificarU
            // 
            this.btnModificarU.Location = new System.Drawing.Point(130, 67);
            this.btnModificarU.Name = "btnModificarU";
            this.btnModificarU.Size = new System.Drawing.Size(75, 34);
            this.btnModificarU.TabIndex = 4;
            this.btnModificarU.Text = "Modificar Usuario";
            this.btnModificarU.UseVisualStyleBackColor = true;
            this.btnModificarU.Click += new System.EventHandler(this.btnModificarU_Click);
            // 
            // btnFunciones
            // 
            this.btnFunciones.Location = new System.Drawing.Point(286, 113);
            this.btnFunciones.Name = "btnFunciones";
            this.btnFunciones.Size = new System.Drawing.Size(237, 21);
            this.btnFunciones.TabIndex = 20;
            this.btnFunciones.Text = "Modificar  Reglamento";
            this.btnFunciones.UseVisualStyleBackColor = true;
            this.btnFunciones.Click += new System.EventHandler(this.btnFunciones_Click);
            // 
            // pnElimina
            // 
            this.pnElimina.BackColor = System.Drawing.Color.DarkGray;
            this.pnElimina.Controls.Add(this.btnEliminado);
            this.pnElimina.Controls.Add(this.txtNomEliminar);
            this.pnElimina.Controls.Add(this.lblEliminacion);
            this.pnElimina.Location = new System.Drawing.Point(915, 230);
            this.pnElimina.Name = "pnElimina";
            this.pnElimina.Size = new System.Drawing.Size(211, 77);
            this.pnElimina.TabIndex = 21;
            this.pnElimina.Visible = false;
            // 
            // btnEliminado
            // 
            this.btnEliminado.Location = new System.Drawing.Point(59, 48);
            this.btnEliminado.Name = "btnEliminado";
            this.btnEliminado.Size = new System.Drawing.Size(75, 23);
            this.btnEliminado.TabIndex = 2;
            this.btnEliminado.Text = "Aceptar";
            this.btnEliminado.UseVisualStyleBackColor = true;
            this.btnEliminado.Click += new System.EventHandler(this.btnEliminado_Click);
            // 
            // txtNomEliminar
            // 
            this.txtNomEliminar.Location = new System.Drawing.Point(50, 22);
            this.txtNomEliminar.Name = "txtNomEliminar";
            this.txtNomEliminar.Size = new System.Drawing.Size(100, 20);
            this.txtNomEliminar.TabIndex = 1;
            // 
            // lblEliminacion
            // 
            this.lblEliminacion.AutoSize = true;
            this.lblEliminacion.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEliminacion.Location = new System.Drawing.Point(13, 0);
            this.lblEliminacion.Name = "lblEliminacion";
            this.lblEliminacion.Size = new System.Drawing.Size(171, 20);
            this.lblEliminacion.TabIndex = 0;
            this.lblEliminacion.Text = "Nombre Usuario a Eliminar :(";
            this.lblEliminacion.UseMnemonic = false;
            // 
            // pnModificar
            // 
            this.pnModificar.BackColor = System.Drawing.Color.DarkGray;
            this.pnModificar.Controls.Add(this.btnModificado);
            this.pnModificar.Controls.Add(this.txtUsuarioModificar);
            this.pnModificar.Controls.Add(this.lblModificar);
            this.pnModificar.Location = new System.Drawing.Point(915, 313);
            this.pnModificar.Name = "pnModificar";
            this.pnModificar.Size = new System.Drawing.Size(211, 77);
            this.pnModificar.TabIndex = 22;
            this.pnModificar.Visible = false;
            // 
            // btnModificado
            // 
            this.btnModificado.Location = new System.Drawing.Point(59, 48);
            this.btnModificado.Name = "btnModificado";
            this.btnModificado.Size = new System.Drawing.Size(75, 23);
            this.btnModificado.TabIndex = 2;
            this.btnModificado.Text = "Aceptar";
            this.btnModificado.UseVisualStyleBackColor = true;
            this.btnModificado.Click += new System.EventHandler(this.btnModificado_Click);
            // 
            // txtUsuarioModificar
            // 
            this.txtUsuarioModificar.Location = new System.Drawing.Point(50, 22);
            this.txtUsuarioModificar.Name = "txtUsuarioModificar";
            this.txtUsuarioModificar.Size = new System.Drawing.Size(100, 20);
            this.txtUsuarioModificar.TabIndex = 1;
            // 
            // lblModificar
            // 
            this.lblModificar.AutoSize = true;
            this.lblModificar.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModificar.Location = new System.Drawing.Point(21, 6);
            this.lblModificar.Name = "lblModificar";
            this.lblModificar.Size = new System.Drawing.Size(163, 20);
            this.lblModificar.TabIndex = 0;
            this.lblModificar.Text = "Nombre Usuario a Modificar";
            this.lblModificar.UseMnemonic = false;
            // 
            // pnLeyes
            // 
            this.pnLeyes.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnLeyes.Controls.Add(this.button4);
            this.pnLeyes.Controls.Add(this.btnprest);
            this.pnLeyes.Controls.Add(this.btnFunciones);
            this.pnLeyes.Controls.Add(this.lblLeyMod);
            this.pnLeyes.Controls.Add(this.label6);
            this.pnLeyes.Controls.Add(this.rbtnLeyNueva);
            this.pnLeyes.Controls.Add(this.rLblLeyExistente);
            this.pnLeyes.Controls.Add(this.btnEliminarLey);
            this.pnLeyes.Controls.Add(this.btnModLey);
            this.pnLeyes.Controls.Add(this.label5);
            this.pnLeyes.Controls.Add(this.btnGuardarRegla);
            this.pnLeyes.Controls.Add(this.btnGuardarLey);
            this.pnLeyes.Controls.Add(this.lblReglamento);
            this.pnLeyes.Controls.Add(this.txtReglamento);
            this.pnLeyes.Controls.Add(this.btnGuardarCantRegla);
            this.pnLeyes.Controls.Add(this.mTxtCantRegla);
            this.pnLeyes.Controls.Add(this.lblCantidadReglamentos);
            this.pnLeyes.Controls.Add(this.btnLeyCreada);
            this.pnLeyes.Controls.Add(this.btnAgregarLeyExistente);
            this.pnLeyes.Controls.Add(this.btnCreado);
            this.pnLeyes.Controls.Add(this.txtLeyNueva);
            this.pnLeyes.Controls.Add(this.txtLeyExistente);
            this.pnLeyes.Location = new System.Drawing.Point(8, 230);
            this.pnLeyes.Name = "pnLeyes";
            this.pnLeyes.Size = new System.Drawing.Size(538, 337);
            this.pnLeyes.TabIndex = 23;
            this.pnLeyes.Visible = false;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(447, 58);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 28;
            this.button4.Text = "Devolver";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnprest
            // 
            this.btnprest.Location = new System.Drawing.Point(367, 58);
            this.btnprest.Name = "btnprest";
            this.btnprest.Size = new System.Drawing.Size(74, 23);
            this.btnprest.TabIndex = 27;
            this.btnprest.Text = "Préstamo";
            this.btnprest.UseVisualStyleBackColor = true;
            this.btnprest.Click += new System.EventHandler(this.btnprest_Click);
            // 
            // lblLeyMod
            // 
            this.lblLeyMod.AutoSize = true;
            this.lblLeyMod.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLeyMod.Location = new System.Drawing.Point(61, 147);
            this.lblLeyMod.Name = "lblLeyMod";
            this.lblLeyMod.Size = new System.Drawing.Size(164, 20);
            this.lblLeyMod.TabIndex = 24;
            this.lblLeyMod.Text = "Ingrese Nombre Ley Nueva: ";
            this.lblLeyMod.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(180, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(223, 19);
            this.label6.TabIndex = 23;
            this.label6.Text = "SELECCIONE UN CAMPO POR FAVOR";
            // 
            // rbtnLeyNueva
            // 
            this.rbtnLeyNueva.AutoSize = true;
            this.rbtnLeyNueva.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnLeyNueva.Location = new System.Drawing.Point(22, 145);
            this.rbtnLeyNueva.Name = "rbtnLeyNueva";
            this.rbtnLeyNueva.Size = new System.Drawing.Size(83, 24);
            this.rbtnLeyNueva.TabIndex = 22;
            this.rbtnLeyNueva.TabStop = true;
            this.rbtnLeyNueva.Text = "Ley Nueva";
            this.rbtnLeyNueva.UseVisualStyleBackColor = true;
            this.rbtnLeyNueva.CheckedChanged += new System.EventHandler(this.rbtnLeyNueva_CheckedChanged);
            // 
            // rLblLeyExistente
            // 
            this.rLblLeyExistente.AutoSize = true;
            this.rLblLeyExistente.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rLblLeyExistente.Location = new System.Drawing.Point(22, 58);
            this.rLblLeyExistente.Name = "rLblLeyExistente";
            this.rLblLeyExistente.Size = new System.Drawing.Size(103, 24);
            this.rLblLeyExistente.TabIndex = 21;
            this.rLblLeyExistente.TabStop = true;
            this.rLblLeyExistente.Text = "Ley Existente";
            this.rLblLeyExistente.UseVisualStyleBackColor = true;
            this.rLblLeyExistente.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // btnEliminarLey
            // 
            this.btnEliminarLey.Location = new System.Drawing.Point(448, 84);
            this.btnEliminarLey.Name = "btnEliminarLey";
            this.btnEliminarLey.Size = new System.Drawing.Size(75, 23);
            this.btnEliminarLey.TabIndex = 20;
            this.btnEliminarLey.Text = "Eliminar";
            this.btnEliminarLey.UseVisualStyleBackColor = true;
            this.btnEliminarLey.Click += new System.EventHandler(this.btnEliminarLey_Click);
            // 
            // btnModLey
            // 
            this.btnModLey.Location = new System.Drawing.Point(366, 84);
            this.btnModLey.Name = "btnModLey";
            this.btnModLey.Size = new System.Drawing.Size(75, 23);
            this.btnModLey.TabIndex = 19;
            this.btnModLey.Text = "Modificar";
            this.btnModLey.UseVisualStyleBackColor = true;
            this.btnModLey.Click += new System.EventHandler(this.btnModLey_Click);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Haettenschweiler", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label5.Location = new System.Drawing.Point(36, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(417, 55);
            this.label5.TabIndex = 18;
            this.label5.Text = "LEYES";
            // 
            // btnGuardarRegla
            // 
            this.btnGuardarRegla.Location = new System.Drawing.Point(285, 281);
            this.btnGuardarRegla.Name = "btnGuardarRegla";
            this.btnGuardarRegla.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarRegla.TabIndex = 17;
            this.btnGuardarRegla.Text = "Guardar";
            this.btnGuardarRegla.UseVisualStyleBackColor = true;
            this.btnGuardarRegla.Click += new System.EventHandler(this.btnGuardarRegla_Click);
            // 
            // btnGuardarLey
            // 
            this.btnGuardarLey.Location = new System.Drawing.Point(285, 166);
            this.btnGuardarLey.Name = "btnGuardarLey";
            this.btnGuardarLey.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarLey.TabIndex = 16;
            this.btnGuardarLey.Text = "Guardar";
            this.btnGuardarLey.UseVisualStyleBackColor = true;
            this.btnGuardarLey.Click += new System.EventHandler(this.btnGuardarLey_Click);
            // 
            // lblReglamento
            // 
            this.lblReglamento.AutoSize = true;
            this.lblReglamento.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReglamento.Location = new System.Drawing.Point(21, 262);
            this.lblReglamento.Name = "lblReglamento";
            this.lblReglamento.Size = new System.Drawing.Size(82, 20);
            this.lblReglamento.TabIndex = 15;
            this.lblReglamento.Text = "Reglamentos";
            // 
            // txtReglamento
            // 
            this.txtReglamento.Location = new System.Drawing.Point(21, 284);
            this.txtReglamento.Name = "txtReglamento";
            this.txtReglamento.Size = new System.Drawing.Size(257, 20);
            this.txtReglamento.TabIndex = 14;
            // 
            // btnGuardarCantRegla
            // 
            this.btnGuardarCantRegla.Location = new System.Drawing.Point(109, 225);
            this.btnGuardarCantRegla.Name = "btnGuardarCantRegla";
            this.btnGuardarCantRegla.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarCantRegla.TabIndex = 13;
            this.btnGuardarCantRegla.Text = "Guardar";
            this.btnGuardarCantRegla.UseVisualStyleBackColor = true;
            this.btnGuardarCantRegla.Click += new System.EventHandler(this.btnGuardarCantRegla_Click);
            // 
            // mTxtCantRegla
            // 
            this.mTxtCantRegla.Location = new System.Drawing.Point(22, 228);
            this.mTxtCantRegla.Mask = "99999";
            this.mTxtCantRegla.Name = "mTxtCantRegla";
            this.mTxtCantRegla.Size = new System.Drawing.Size(81, 20);
            this.mTxtCantRegla.TabIndex = 12;
            this.mTxtCantRegla.ValidatingType = typeof(int);
            // 
            // lblCantidadReglamentos
            // 
            this.lblCantidadReglamentos.AutoSize = true;
            this.lblCantidadReglamentos.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCantidadReglamentos.Location = new System.Drawing.Point(18, 205);
            this.lblCantidadReglamentos.Name = "lblCantidadReglamentos";
            this.lblCantidadReglamentos.Size = new System.Drawing.Size(177, 20);
            this.lblCantidadReglamentos.TabIndex = 11;
            this.lblCantidadReglamentos.Text = "Ingrese Cantidad Reglamentos";
            // 
            // btnLeyCreada
            // 
            this.btnLeyCreada.Location = new System.Drawing.Point(270, 208);
            this.btnLeyCreada.Name = "btnLeyCreada";
            this.btnLeyCreada.Size = new System.Drawing.Size(144, 58);
            this.btnLeyCreada.TabIndex = 5;
            this.btnLeyCreada.Text = "Crear Ley";
            this.btnLeyCreada.UseVisualStyleBackColor = true;
            this.btnLeyCreada.Click += new System.EventHandler(this.btnLeyCreada_Click);
            // 
            // btnAgregarLeyExistente
            // 
            this.btnAgregarLeyExistente.Location = new System.Drawing.Point(286, 58);
            this.btnAgregarLeyExistente.Name = "btnAgregarLeyExistente";
            this.btnAgregarLeyExistente.Size = new System.Drawing.Size(75, 49);
            this.btnAgregarLeyExistente.TabIndex = 4;
            this.btnAgregarLeyExistente.Text = "Préstamo por Lote";
            this.btnAgregarLeyExistente.UseVisualStyleBackColor = true;
            this.btnAgregarLeyExistente.Click += new System.EventHandler(this.btnAgregarLeyExistente_Click);
            // 
            // txtLeyNueva
            // 
            this.txtLeyNueva.Location = new System.Drawing.Point(21, 169);
            this.txtLeyNueva.Name = "txtLeyNueva";
            this.txtLeyNueva.Size = new System.Drawing.Size(257, 20);
            this.txtLeyNueva.TabIndex = 2;
            // 
            // txtLeyExistente
            // 
            this.txtLeyExistente.Location = new System.Drawing.Point(22, 85);
            this.txtLeyExistente.Name = "txtLeyExistente";
            this.txtLeyExistente.Size = new System.Drawing.Size(257, 20);
            this.txtLeyExistente.TabIndex = 1;
            // 
            // pnDevolver
            // 
            this.pnDevolver.BackColor = System.Drawing.Color.SeaGreen;
            this.pnDevolver.Controls.Add(this.lblDevolver);
            this.pnDevolver.Controls.Add(this.txtDevolver);
            this.pnDevolver.Controls.Add(this.button2);
            this.pnDevolver.Location = new System.Drawing.Point(552, 416);
            this.pnDevolver.Name = "pnDevolver";
            this.pnDevolver.Size = new System.Drawing.Size(357, 94);
            this.pnDevolver.TabIndex = 24;
            this.pnDevolver.Visible = false;
            // 
            // lblDevolver
            // 
            this.lblDevolver.AutoSize = true;
            this.lblDevolver.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDevolver.Location = new System.Drawing.Point(12, 8);
            this.lblDevolver.Name = "lblDevolver";
            this.lblDevolver.Size = new System.Drawing.Size(223, 20);
            this.lblDevolver.TabIndex = 2;
            this.lblDevolver.Text = "Ingrese el Nombre de la Ley a Devolver";
            // 
            // txtDevolver
            // 
            this.txtDevolver.Location = new System.Drawing.Point(16, 31);
            this.txtDevolver.Name = "txtDevolver";
            this.txtDevolver.Size = new System.Drawing.Size(326, 20);
            this.txtDevolver.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(267, 56);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "Devolver";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pnInformes
            // 
            this.pnInformes.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnInformes.Controls.Add(this.btnInformeGrupo);
            this.pnInformes.Controls.Add(this.btnInformeLey);
            this.pnInformes.Location = new System.Drawing.Point(915, 396);
            this.pnInformes.Name = "pnInformes";
            this.pnInformes.Size = new System.Drawing.Size(213, 88);
            this.pnInformes.TabIndex = 21;
            this.pnInformes.Visible = false;
            // 
            // btnInformeGrupo
            // 
            this.btnInformeGrupo.Location = new System.Drawing.Point(117, 20);
            this.btnInformeGrupo.Name = "btnInformeGrupo";
            this.btnInformeGrupo.Size = new System.Drawing.Size(74, 51);
            this.btnInformeGrupo.TabIndex = 1;
            this.btnInformeGrupo.Text = "Informe Grupo";
            this.btnInformeGrupo.UseVisualStyleBackColor = true;
            this.btnInformeGrupo.Click += new System.EventHandler(this.btnInformeGrupo_Click);
            // 
            // btnInformeLey
            // 
            this.btnInformeLey.Location = new System.Drawing.Point(25, 20);
            this.btnInformeLey.Name = "btnInformeLey";
            this.btnInformeLey.Size = new System.Drawing.Size(75, 51);
            this.btnInformeLey.TabIndex = 0;
            this.btnInformeLey.Text = "Informe por Ley";
            this.btnInformeLey.UseVisualStyleBackColor = true;
            this.btnInformeLey.Click += new System.EventHandler(this.btnInformeLey_Click);
            // 
            // DGVMuestraLeyes
            // 
            this.DGVMuestraLeyes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVMuestraLeyes.Location = new System.Drawing.Point(719, 3);
            this.DGVMuestraLeyes.Name = "DGVMuestraLeyes";
            this.DGVMuestraLeyes.Size = new System.Drawing.Size(407, 221);
            this.DGVMuestraLeyes.TabIndex = 25;
            this.DGVMuestraLeyes.Visible = false;
            this.DGVMuestraLeyes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVMuestraLeyes_CellContentClick);
            // 
            // pnReglamento
            // 
            this.pnReglamento.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.pnReglamento.Controls.Add(this.button3);
            this.pnReglamento.Controls.Add(this.lblNomLeyRegla);
            this.pnReglamento.Controls.Add(this.txtModRegla);
            this.pnReglamento.Controls.Add(this.btnEliminarReglamento);
            this.pnReglamento.Controls.Add(this.btnGuardarReglaMod);
            this.pnReglamento.Controls.Add(this.txtNewName);
            this.pnReglamento.Controls.Add(this.btnModificarRegla);
            this.pnReglamento.Controls.Add(this.txtReglaAMod);
            this.pnReglamento.Controls.Add(this.lblReglaModi);
            this.pnReglamento.Location = new System.Drawing.Point(552, 516);
            this.pnReglamento.Name = "pnReglamento";
            this.pnReglamento.Size = new System.Drawing.Size(559, 136);
            this.pnReglamento.TabIndex = 26;
            this.pnReglamento.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(378, 28);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 32;
            this.button3.Text = "Buscar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // lblNomLeyRegla
            // 
            this.lblNomLeyRegla.AutoSize = true;
            this.lblNomLeyRegla.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomLeyRegla.Location = new System.Drawing.Point(12, 8);
            this.lblNomLeyRegla.Name = "lblNomLeyRegla";
            this.lblNomLeyRegla.Size = new System.Drawing.Size(144, 20);
            this.lblNomLeyRegla.TabIndex = 31;
            this.lblNomLeyRegla.Text = "Ley que Desea Modificar";
            // 
            // txtModRegla
            // 
            this.txtModRegla.Location = new System.Drawing.Point(17, 31);
            this.txtModRegla.Name = "txtModRegla";
            this.txtModRegla.Size = new System.Drawing.Size(355, 20);
            this.txtModRegla.TabIndex = 27;
            // 
            // btnEliminarReglamento
            // 
            this.btnEliminarReglamento.Location = new System.Drawing.Point(460, 74);
            this.btnEliminarReglamento.Name = "btnEliminarReglamento";
            this.btnEliminarReglamento.Size = new System.Drawing.Size(75, 23);
            this.btnEliminarReglamento.TabIndex = 30;
            this.btnEliminarReglamento.Text = "Eliminar";
            this.btnEliminarReglamento.UseVisualStyleBackColor = true;
            this.btnEliminarReglamento.Visible = false;
            this.btnEliminarReglamento.Click += new System.EventHandler(this.btnEliminarReglamento_Click);
            // 
            // btnGuardarReglaMod
            // 
            this.btnGuardarReglaMod.Location = new System.Drawing.Point(378, 104);
            this.btnGuardarReglaMod.Name = "btnGuardarReglaMod";
            this.btnGuardarReglaMod.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarReglaMod.TabIndex = 29;
            this.btnGuardarReglaMod.Text = "Guardar";
            this.btnGuardarReglaMod.UseVisualStyleBackColor = true;
            this.btnGuardarReglaMod.Visible = false;
            // 
            // txtNewName
            // 
            this.txtNewName.Location = new System.Drawing.Point(17, 107);
            this.txtNewName.Name = "txtNewName";
            this.txtNewName.Size = new System.Drawing.Size(355, 20);
            this.txtNewName.TabIndex = 28;
            this.txtNewName.Visible = false;
            // 
            // btnModificarRegla
            // 
            this.btnModificarRegla.Location = new System.Drawing.Point(378, 75);
            this.btnModificarRegla.Name = "btnModificarRegla";
            this.btnModificarRegla.Size = new System.Drawing.Size(75, 23);
            this.btnModificarRegla.TabIndex = 27;
            this.btnModificarRegla.Text = "Modificar";
            this.btnModificarRegla.UseVisualStyleBackColor = true;
            this.btnModificarRegla.Click += new System.EventHandler(this.btnModificarRegla_Click);
            // 
            // txtReglaAMod
            // 
            this.txtReglaAMod.Location = new System.Drawing.Point(17, 77);
            this.txtReglaAMod.Name = "txtReglaAMod";
            this.txtReglaAMod.Size = new System.Drawing.Size(355, 20);
            this.txtReglaAMod.TabIndex = 17;
            // 
            // lblReglaModi
            // 
            this.lblReglaModi.AutoSize = true;
            this.lblReglaModi.Font = new System.Drawing.Font("Buxton Sketch", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReglaModi.Location = new System.Drawing.Point(12, 54);
            this.lblReglaModi.Name = "lblReglaModi";
            this.lblReglaModi.Size = new System.Drawing.Size(147, 20);
            this.lblReglaModi.TabIndex = 16;
            this.lblReglaModi.Text = "Reglamentos A Modificar";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1172, 669);
            this.Controls.Add(this.pnReglamento);
            this.Controls.Add(this.DGVMuestraLeyes);
            this.Controls.Add(this.pnInformes);
            this.Controls.Add(this.pnDevolver);
            this.Controls.Add(this.pnLeyes);
            this.Controls.Add(this.pnModificar);
            this.Controls.Add(this.pnElimina);
            this.Controls.Add(this.pnUsuario);
            this.Controls.Add(this.pnCreate);
            this.Controls.Add(this.pnInicio);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnInicio.ResumeLayout(false);
            this.pnInicio.PerformLayout();
            this.pnCreate.ResumeLayout(false);
            this.pnCreate.PerformLayout();
            this.pnUsuario.ResumeLayout(false);
            this.pnElimina.ResumeLayout(false);
            this.pnElimina.PerformLayout();
            this.pnModificar.ResumeLayout(false);
            this.pnModificar.PerformLayout();
            this.pnLeyes.ResumeLayout(false);
            this.pnLeyes.PerformLayout();
            this.pnDevolver.ResumeLayout(false);
            this.pnDevolver.PerformLayout();
            this.pnInformes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVMuestraLeyes)).EndInit();
            this.pnReglamento.ResumeLayout(false);
            this.pnReglamento.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnInicio;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnLogIn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtContra;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnCreate;
        private System.Windows.Forms.TextBox txtContraseña;
        private System.Windows.Forms.Label lblContra;
        private System.Windows.Forms.Button btnContra;
        private System.Windows.Forms.Button btnNom;
        private System.Windows.Forms.Button GuardarCantAsesor;
        private System.Windows.Forms.MaskedTextBox mTxtCasesores;
        private System.Windows.Forms.Label lblCantA;
        private System.Windows.Forms.Button btnGuardarAse;
        private System.Windows.Forms.TextBox txtNomAsesor;
        private System.Windows.Forms.Label lblNomA;
        private System.Windows.Forms.Button btnCreado;
        private System.Windows.Forms.TextBox txtNombreDip;
        private System.Windows.Forms.Label lblDip;
        private System.Windows.Forms.Panel pnUsuario;
        private System.Windows.Forms.Button btnEliminarU;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnModificarU;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnAgregarLeyes;
        private System.Windows.Forms.Panel pnElimina;
        private System.Windows.Forms.Button btnEliminado;
        private System.Windows.Forms.TextBox txtNomEliminar;
        private System.Windows.Forms.Label lblEliminacion;
        private System.Windows.Forms.Label lblMake;
        private System.Windows.Forms.Label lblPerfil;
        private System.Windows.Forms.Panel pnModificar;
        private System.Windows.Forms.Button btnModificado;
        private System.Windows.Forms.TextBox txtUsuarioModificar;
        private System.Windows.Forms.Label lblModificar;
        private System.Windows.Forms.Panel pnLeyes;
        private System.Windows.Forms.Button btnGuardarRegla;
        private System.Windows.Forms.Button btnGuardarLey;
        private System.Windows.Forms.Label lblReglamento;
        private System.Windows.Forms.TextBox txtReglamento;
        private System.Windows.Forms.Button btnGuardarCantRegla;
        private System.Windows.Forms.MaskedTextBox mTxtCantRegla;
        private System.Windows.Forms.Label lblCantidadReglamentos;
        private System.Windows.Forms.Button btnLeyCreada;
        private System.Windows.Forms.Button btnAgregarLeyExistente;
        private System.Windows.Forms.TextBox txtLeyNueva;
        private System.Windows.Forms.TextBox txtLeyExistente;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSiguiente;
        private System.Windows.Forms.Button btnEliminarLey;
        private System.Windows.Forms.Button btnModLey;
        private System.Windows.Forms.RadioButton rLblLeyExistente;
        private System.Windows.Forms.RadioButton rbtnLeyNueva;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnFunciones;
        private System.Windows.Forms.Panel pnDevolver;
        private System.Windows.Forms.Label lblDevolver;
        private System.Windows.Forms.TextBox txtDevolver;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel pnInformes;
        private System.Windows.Forms.Button btnInformeGrupo;
        private System.Windows.Forms.Button btnInformeLey;
        private System.Windows.Forms.Label lblLeyMod;
        private System.Windows.Forms.DataGridView DGVMuestraLeyes;
        private System.Windows.Forms.Panel pnReglamento;
        private System.Windows.Forms.Button btnGuardarReglaMod;
        private System.Windows.Forms.TextBox txtNewName;
        private System.Windows.Forms.Button btnModificarRegla;
        private System.Windows.Forms.TextBox txtReglaAMod;
        private System.Windows.Forms.Label lblReglaModi;
        private System.Windows.Forms.TextBox txtModRegla;
        private System.Windows.Forms.Button btnEliminarReglamento;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label lblNomLeyRegla;
        private System.Windows.Forms.Button btnprest;
        private System.Windows.Forms.Button button4;
    }
}

