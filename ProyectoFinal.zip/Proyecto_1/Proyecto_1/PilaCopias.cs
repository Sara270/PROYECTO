﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_1
{
   public class PilaCopias
    {
        public static string Name
        {
            get { return Name = " "; }
            set { Name = value; }
        }

        private int cima3;
        private int limite3;
        public PilaCopias valor3;
        private PilaCopias[] copias;
        private bool vacio3;
        private bool lleno3;

         public PilaCopias()
        {
            cima3 = 0;
            limite3 = 4;
           
            copias = new PilaCopias[limite3];
            vacio3 = false;
            lleno3 = false;
        }
        
         private bool Valida_vacia()
         {
             if (copias[0] == default(PilaCopias))
             {
                 vacio3 = true;
             }
             else
             {
                 vacio3 = false;
             }
             return vacio3;
         }
         private bool Valida_lleno()
         {
             if (copias[0] != default(PilaCopias))
             {
                 lleno3 = true;
             }
             else
             {
                 lleno3 = false;
             }
             return lleno3;
         }
         public void Push(PilaCopias copia)
         {
             if (Valida_vacia() && cima3 < 0)
             {
                 copias[0] = copia;
                 cima3++;
             }
             else
             {
                 if (cima3 < limite3)
                 {
                     cima3++;
                     copias[cima3] = copia;
                 }
             }
         }

         public PilaCopias Pop()
         {
             if (Valida_lleno())
             {
                 valor3 = copias[cima3];
                 copias[cima3] = default(PilaCopias);
                 cima3--;
             }
             else
             {
                 Console.WriteLine("Ingreso a Lista de Espera");
             }
             return valor3;
         }

         public int Count()
         {
             return copias.Count();
         }
    }
}
