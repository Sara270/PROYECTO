﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SisLey_ProyectoNo._1
{
   public class Lista
    {
        private string[] listaAsesor;
        private Ley [] listaLeyes;
        private int cima=-1;
        private int limite;
        private bool vacio;
        private bool lleno;
        /////////////////////////////////
        private string valor;
        private Ley valor2;


        public Lista(bool Diferenciar, int cantidadA)
        {
            if (Diferenciar == true){ /// no es necesario el true
                listaAsesor = new string[cantidadA];
                
            }
            else{
                listaLeyes = new Ley[80];
            }
            limite = cantidadA;
        }

        private bool Valida_vacia_Asesor()
        {
            if (listaAsesor[0] == default(string))
            {
                vacio = true;
            }
            else
            {
                vacio = false;
            }
            return vacio;
        }

        private bool Valida_vacia_Leyes()
        {
            if (listaLeyes[0] == default(Ley))
            {
                vacio = true;
            }
            else
            {
                vacio = false;
            }
            return vacio;
        }

        private bool Valida_lleno_Asesor()
        {
            if (listaAsesor[0] != default(string))
            {
                lleno = true;
            }
            else
            {
                lleno = false;
            }
            return lleno;
        }

        private bool Valida_lleno_Leyes()
        {
            if (listaLeyes[0] != default(Ley))
            {
                lleno = true;
            }
            else
            {
                lleno = false;
            }
            return lleno;
        }

        public void Add_Asesor(string d)
        {
            if (Valida_vacia_Asesor() && cima < 0)
            {
                listaAsesor[0] = d;
                cima++;
            }
            else
            {
                if (cima < limite)
                {
                    cima++;
                    listaAsesor[cima] = d;
                }
            } 
        }
        public void Add_Leyes(Ley e)
        {
            if (Valida_vacia_Leyes() && cima < 0)
            {
                listaLeyes[0] = e;
                cima++;
            }
            else
            {
                if (cima < limite)
                {
                    cima++;
                    listaLeyes[cima] = e;
                }
            }
        }

        // Revisar 

        public string Remove(int puntero)
        {
            if (Valida_lleno_Asesor() && puntero <= cima)
            {
                if (puntero == cima)
                {
                    valor = listaAsesor[puntero];
                    listaAsesor[cima] = default(string);
                    cima--;
                }
                else
                {
                    valor = listaAsesor[puntero];
                    for (int i = puntero; i < cima; i++)
                    {
                        listaAsesor[i] = listaAsesor[i + 1];
                    }
                    listaAsesor[cima] = default(string);
                    cima--;
                }
            }
            else
            {
                Console.WriteLine("La lista no posee valor en la posicion especificada");
            }
            return valor; 
        }

        public Ley Remove1(int puntero1)
        {
            if (Valida_lleno_Leyes() && puntero1 <= cima)
            {
                if (puntero1 == cima)
                {
                    valor2 = listaLeyes[puntero1];
                    listaLeyes[cima] = default(Ley);
                    cima--;
                }
                else
                {
                    valor2 = listaLeyes[puntero1];
                    for (int i = puntero1; i < cima; i++)
                    {
                        listaLeyes[i] = listaLeyes[i + 1];
                    }
                    listaLeyes[cima] = default(Ley);
                    cima--;
                }
            }
            else
            {
                Console.WriteLine("La lista no posee valor en la posicion especificada");
            }
            return valor2;
        }
    }
}
