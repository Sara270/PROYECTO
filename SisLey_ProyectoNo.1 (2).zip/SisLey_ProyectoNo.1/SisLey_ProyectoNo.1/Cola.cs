﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SisLey_ProyectoNo._1
{
    class Cola
    {
        private Asesor[] listaAsesor;
        private Ley[] listaLeyes;
        private int cima=-1;
        private int limite;
        private bool vacio;
        private bool lleno;
        
        //////////////////////////////////////////////////////
       
        private Asesor inicio;
        private Ley inicio2;

        public Cola(bool Diferenciar)
        {
            if (Diferenciar == true){
                listaAsesor = new Asesor[8];
            }
            else{
                listaLeyes = new Ley[5];
            }
        }

        private bool Valida_vacia_Asesor()
        {
            if (listaAsesor[0] == default(Asesor))
            {
                vacio = true;
            }
            else
            {
                vacio = false;
            }
            return vacio;
        }

        private bool Valida_vacia_Leyes()
        {
            if (listaLeyes[0] == default(Ley))
            {
                vacio = true;
            }
            else
            {
                vacio = false;
            }
            return vacio;
        }

        private bool Valida_lleno_Asesor()
        {
            if (listaAsesor[0] != default(Asesor))
            {
                lleno = true;
            }
            else
            {
                lleno = false;
            }
            return lleno;
        }

        private bool Valida_lleno_Ley()
        {
            if (listaLeyes[0] != default(Ley))
            {
                lleno = true;
            }
            else
            {
                lleno = false;
            }
            return lleno;
        }

        public void Enqueue_Asesor(Asesor h)
        {
            if (Valida_vacia_Asesor() && cima < 0)
            {
                listaAsesor[0] = h;
                cima++;
            }
            else
            {
                if (cima < limite)
                {
                    cima++;
                    listaAsesor[cima] = h;
                }
            }
        }
        public void Enqueue_Ley(Ley k)
        {
            if (Valida_vacia_Leyes() && cima < 0)
            {
                listaLeyes[0] = k;
                cima++;
            }
            else
            {
                if (cima < limite)
                {
                    cima++;
                    listaLeyes[cima] = k;
                }
            }
        }
        public Asesor Dequeue_Asesor()
        {
            if (Valida_lleno_Asesor())
            {
                inicio = listaAsesor[0];
                for (int i = 0; i < cima; i++)
                {
                    listaAsesor[i] = listaAsesor[i + 1];
                }
                listaAsesor[cima] = default(Asesor);
                cima--;
            }
            else
            {
                Console.WriteLine("La cola esta vacia");
            }
            return inicio; 
        }
        public Ley Dequeue_Leyes()
        {
            if (Valida_lleno_Ley())
            {
                inicio2 = listaLeyes[0];
                for (int i = 0; i < cima; i++)
                {
                    listaLeyes[i] = listaLeyes[i + 1];
                }
                listaLeyes[cima] = default(Ley);
                cima--;
            }
            else
            {
                Console.WriteLine("La cola esta vacia");
            }
            return inicio2;
        }

    }
}
