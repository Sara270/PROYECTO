﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SisLey_ProyectoNo._1
{
    public class Usuarios
    {
        private Ley[] Leyes;
        private Reglamentos[] Reglamentos;
        public Lista listaAsesor;
        private string nombre;
        public string [] nombreAse;
        //private Lista [] listau;
        int asesoresc;
        public Usuarios (string nombre, int asesoresc, Lista nombreAse){
            this.nombre = nombre;
            this.asesoresc = asesoresc;
            this.listaAsesor = nombreAse;
    }


        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        private string contraseña;

        public string Contraseña
        {
            get { return contraseña; }
            set { contraseña = value; }
        }

        //public void ArregloAsesor()
        //{
        //    listaAsesor = new Lista(true, asesoresc);
        //    for (int i = 0; i < asesoresc; i++)
        //    {
        //        listaAsesor.Add_Asesor(nombreAse);
        //    }
               
        //}


    }
}
